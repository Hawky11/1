# Arcana Heart 3 LOVEMAX SIXSTARS!!!!!! XTEND — Stage 10

Stage 10 продолжает диагностику Stage 9. Это **только сбор данных**: код не меняет решения CPU, аргументы helper-функций, выходные значения, EAX или игровые структуры. Balanciaga не включена.

## Изменения

**Убраны фильтры по caller RVA.** Остаются entry hooks F34D0, F3930, F3280, F4030 и F4360. Recorder принимает вызов для известных объектов P1/P2 при `DWORD [player+0x3F2C] == 1`. Записываются абсолютный адрес caller и RVA; адрес вне AALib.exe помечается 0xFFFFFFFF.

**Все успешные EAX фиксируются.** Любой результат, кроме 0xFFFFFFFF, записывается без выборки. Неуспешные вызовы прореживаются после возврата helper-а: по умолчанию 1/16 отдельно по side/helper/caller-RVA bucket; первый сбой каждого bucket тоже сохраняется. Это исправляет Stage 9, где F4030 прореживалась до вызова.

**Буфер стал кольцевым.** Оба модуля используют повторно используемую очередь на 8192 записей с SRW-блокировкой. Worker забирает запись и освобождает слот до файлового ввода-вывода. Файловые операции выполняются не в игровом потоке. Переполнение очереди учитывается.

**Добавлена корреляция.** Каждая строка включает seq, QPC, абсолютный caller и callerRVA. Сохраняются TID/tick, parent EBP, сторона CPU, player, аргументы, EAX, out4/out5 до и после, 53 DWORD родительского frame и player snapshot. Префиксы PRODUCER_CONTEXT и PARENT_FLOW сохранены.

## ArcanaAI.ini

В [AIResearch]:
- EnableAIProducerContextTrace=1
- ProducerContextTraceFlushIntervalMs=250
- ProducerContextFailedResultSampleInterval=16
- EnableAIParentFlowTrace=1
- ParentFlowTraceFlushIntervalMs=250
- ParentFlowFailedResultSampleInterval=16

Интервал выборки 1..256; 1 означает сохранять все неуспешные вызовы. Старый ParentFlowF4030SampleInterval остаётся fallback. Stage 5 QueueTrace/EventDispatch и Stage 7 FinalCommand остаются включёнными.

## Сборка и запуск

1. Распакуй архив в отдельную папку.
2. Запусти Build.bat и сохрани Build.log при ошибке.
3. После успешной сборки возьми build\dinput8.dll и ArcanaAI.ini.
4. Полностью закрой игру, сделай резервную копию DLL/INI и замени их рядом с AALib.exe.
5. Переименуй старые журналы, проведи 1–2 коротких боя COM vs COM и штатно закрой игру.

Нужны пять свежих файлов: ArcanaAI_ProducerContextTrace.log, ArcanaAI_ParentFlowTrace.log, ArcanaAI_FinalCommandTrace.log, ArcanaAI_QueueTrace.log и ArcanaAI_EventDispatchTrace.log.

Fingerprint EXE и точные прологи по-прежнему проверяются перед установкой хуков. Оригинальные функции вызываются через trampoline и возвращают исходный EAX. Stage 10 не меняет игровые данные или решения AI.

**Важно:** полная сборка MSVC и runtime-проверка должны быть выполнены на Windows пользователя. Изменённый исходник не означает, что DLL уже успешно скомпилирована или проверена в игре.
