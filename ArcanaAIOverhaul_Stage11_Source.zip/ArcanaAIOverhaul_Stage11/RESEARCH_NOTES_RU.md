# Arcana Heart 3 LOVEMAX SIXSTARS!!!!!! XTEND — заметки реверс-инжиниринга

## Проверенный исполняемый файл

Архив `AALib.zip` содержит один файл `AALib.exe`.

- PE32 / Intel 386 (x86).
- ImageBase: `0x00400000`.
- SizeOfImage: `0x0E0EB000`.
- EntryPoint RVA: `0x0020EA6C`.
- SHA-256: `28cd69a7b6219ff0fa101ecebfcbe98962dc3f391b522d1fd6e32c006cf855ba`.
- Импортируется `DINPUT8.dll`, функция `DirectInput8Create`. Это подтверждает обоснованность x86-прокси `dinput8.dll`; прокси должна делегировать вызов системной библиотеке по абсолютному системному пути.

## Рабочий COMvsCOM из пользовательской CT

В загруженной таблице подтверждены DWORD-записи:

| Игрок | RVA от `AALib.exe` | Значение CPU |
|---|---:|---:|
| P1 | `0x0DCA5EA4` | `1` |
| P2 | `0x0DCD0BCC` | `1` |

Состояние CE `[DISABLE]`: P1 = `0`, P2 = `1`. Эти параметры перенесены в bootstrap-модуль и пользователь подтвердил, что автоматический COMvsCOM работает.

## Обнаруженные C++-типы ввода

В MSVC RTTI найдены:

- `GAME_BattleKeyControler` — базовый тип.
- `GAMESTEAM_BattleKeyControler` — Steam-вариант.
- `GAMEJVS_BattleKeyControler` — JVS-вариант.
- `GAMESTEAM_BattleKeyControlerFactory` и `GAMEJVS_BattleKeyControlerFactory`.
- `GAME_InputTask`, `GAME_CKeyRingBuffer`, `GAME_CConsumerControllerTask`, `CCommandPad`.

По RTTI `GAMESTEAM_BattleKeyControler` наследуется от `GAME_BattleKeyControler`, `GAME_KeyControler`, `AA_TaskNode` и `AA_ListNode`. `GAMEJVS_BattleKeyControler` имеет аналогичную базовую иерархию.

Конструктор `GAMESTEAM_BattleKeyControler` находится около VA `0x00437850`; он назначает vtable `0x006FB10C`, выделяет внутренний блок `0x28` байт и инициализирует два набора из `0x1A` элементов. Вариант Steam — реальный слой физического/платформенного боевого ввода. Это полезный путь к командам управления, но **не доказательство, что здесь находится decision-making AI**.

Конструктор `GAMESTEAM_MenuKeyControler` расположен около VA `0x00437940` и назначает другую vtable (`0x006FB154`). Это отдельный контроллер меню.

## Что означает совпадение смещения `+0x3BC`

Пользовательские COM DWORD располагаются по адресам `AALib.exe + RVA` из таблицы. В коде также встречаются обращения к полю `[reg+0x3BC]`, но не все такие обращения относятся к тем же объектам.

В частности, участок `0x0040C91B`–`0x0040C9F1` использует группу полей `+0x3B0..+0x3C0` как индексы/настройки при переносе элементов таблицы ввода. Инициализация около `0x0040B6B3` задаёт ряд значений этой группы. Это другой контекст, поэтому его нельзя ошибочно объявлять обработчиком COM-флага.

Пока не найдено:

- функция, которая принимает решение «человек или CPU» для боевого слота;
- функция выбора следующей атаки CPU;
- таблицы приоритетов/весов атак;
- функция оценки дистанции и состояния противника;
- подтверждённая точка, где CPU формирует следующую команду.

## Следующий диагностический шаг: аппаратные watchpoint'ы из мода

Stage 2 добавляет необязательный read/write tracer непосредственно в `dinput8.dll`.

- Он наблюдает только за двумя подтверждёнными DWORD COMvsCOM.
- Watchpoint'ы устанавливаются автоматически в DR0/DR1 существующих игровых потоков и повторно проверяются для новых потоков.
- Используются 4-байтовые аппаратные data breakpoint'ы с режимом чтение/запись.
- Существующие занятые DR0/DR1 не перезаписываются.
- VEH снимает только свои debug-status bits и продолжает выполнение.
- В лог попадают только обращения, выполненные из адресного пространства `AALib.exe`; собственный COMvsCOM writer и Windows API отфильтровываются.
- Для каждого уникального места доступа записываются `EIP` после операции, RVA, регистры и 24 байта кода вокруг точки возврата. По этим байтам можно статически определить точную инструкцию.
- По умолчанию tracer выключен и не использует debug-регистры.
- Кэш потоков ограничен 256 handle; при превышении пишется предупреждение. Если DR0/DR1 уже заняты, эти регистры не трогаются, такой поток остаётся без watchpoint.

Включение: в `ArcanaAI.ini` установить `EnableControlFieldTrace=1` в секции `[AIResearch]`, перезапустить игру, провести 1–3 COM vs COM боя, закрыть игру и отправить `ArcanaAI_Trace.log`. После сбора выключить параметр обратно (`0`). Это короткая диагностическая сессия; постоянное использование не рекомендуется из-за аппаратных исключений при каждом чтении/записи.

Это диагностический этап, а не модификация поведения AI. Цель — определить реальные точки чтения/записи поля и от них пройти к ветвлению CPU-логики. Пока неизвестно, ведут ли эти поля непосредственно к decision-making или только выбирают режим контроллера; выводы о поведении AI можно делать лишь после анализа собранных EIP/RVA и дизассемблированных инструкций.

## Балансировщик Balanciaga

Код `Balanciaga Final Adjusted` не включается в AI Overhaul: пользователь пояснил, что его цель была компенсировать слабость CPU изменением урона сильных/слабых персонажей. При успешном улучшении поведения ИИ этот нерф/баф больше не нужен.


## Build script diagnostic revision

Build.bat was revised to compile each translation unit separately, put object files under `obj\`, link them explicitly, save all compiler/linker output to `Build.log`, and pause on completion or failure. This revision is intended to expose the first failing source file or linker diagnostic instead of leaving partial `.obj` files without a usable explanation.


## Stage 3 — command resolver `AALib.exe+0xF4030`

Проверена функция от RVA `0x000F4030` до её возврата. Это **не подтверждённый AI decision-maker**, а вспомогательный resolver / validator команд внутри input/action pipeline.

### Call sites

В предоставленном бинарнике найдены два прямых вызова из родительской функции около RVA `0x000F7150`:

- call RVA `0x000F78DE`, return RVA `0x000F78E3`, arg2 = `0x31`;
- call RVA `0x000F7902`, return RVA `0x000F7907`, arg2 = знаковый 16-битный результат вызова VA `0x004E9590`.

Оба пути выполняют `jmp 0x004F7924`, где находятся общие инструкции `add esp,0x14; mov esi,eax`. Для Stage 3 внутренний breakpoint установлен раньше — на общем финальном участке resolver `0x004F4268`. При входном hit breakpoint срабатывает до `push ebp`, поэтому EBP в CONTEXT ещё принадлежит caller; на внутреннем финальном hit EBP уже принадлежит resolver, а `[EBP]` содержит сохранённый caller EBP. Так вход и финализация связываются по TID + saved EBP.

### Аргументы и результаты

В обеих точках `arg1=EDI` — объект бойца; `arg2` — кандидат/код команды; `arg3=ESI` — контекст; `arg4=&[caller EBP-8]`; `arg5=&[caller EBP-4]`. Caller передаёт выходные указатели именно в таком порядке. В resolver arg4/arg5 проверяются на non-null; на successful path запись по arg4 получает boolean, arg5 — mapped value.

В начале функции локальная переменная `[EBP-0xC]` инициализируется `0xFFFFFFFF`. При нахождении кандидата в цикле по общей таблице туда записывается текущий индекс `[EBP-4]`. **Это локальный matched table index, а не возвращаемый EAX.** После проверки индекса функция загружает EAX из `[EBP+0x10]` (локальная копия arg3, которая на успешной ветке может быть заменена результатом helper `0x004F3060`). Следовательно, `0xFFFFFFFF` в `[EBP-0xC]` означает, что индекс не был установлен; итоговое значение EAX соответствует сохранённому `[EBP+0x10]`.

В цикле используется глобальная таблица `0x007FE520`, завершающаяся маркером `0x40`; дополнительно выполняются character-specific mapping lookups. При `DWORD [player+0x3F2C] == 1` есть отдельная проверка slot word `WORD [player + index*0x14 + 0xD22]` против `0xFFFF`. Функция также получает state/mode из `[player+0x3F30]`.

### Stage 3 tracer implementation

Добавлены `src/AICommandTrace.cpp` и `src/AICommandTrace.h`. Трассировщик использует DR2 на входе `AALib.exe+0xF4030` и DR3 на внутреннем финальном участке `AALib.exe+0xF4268`, фильтрует только два известных direct-call return RVA, связывает entry/finalize по thread ID и сохранённому caller EBP. Он снимает входные args, исходные значения output locals, локальный matched table index `[callee EBP-0xC]`, значение `[callee EBP+0x10]`, которое последующая ветка загружает в EAX перед возвратом, и два выходных параметра. Результат пишется в `ArcanaAI_CommandTrace.log`.

DR2/DR3 устанавливаются только если соответствующие enable/config поля свободны; существующие debug-register owners не перезаписываются. COMvsCOM writer thread исключён. Статический fingerprint перед установкой: SizeOfImage `0x0E0EB000`, TimeDateStamp `0x5FE5AA91`. Конфигурация по умолчанию выключена: `EnableCommandResolveTrace=0`; для короткого теста включить `1`, при этом `EnableControlFieldTrace=0`.

**Следующий аналитический шаг после пользовательского лога:** сгруппировать `arg2_candidate`, исходный `arg3`, `matchedTableIndex_local_mC`, `expectedReturnValue_arg3` и два output value для P1/P2; сопоставить второй call path `arg2_candidate` с реальным результатом `0x4E9590`; затем проследить вверх, где формируются arg2/arg3 и кто вызывает parent routine. Не объявлять этот resolver алгоритмом AI, пока не найдена функция, которая выбирает саму команду.


### Уточнение Stage 3: внутренний финальный участок resolver

При внимательном прохождении эпилога `0x004F4030` выяснилось, что прежняя формулировка «return EAX = matched table index» была неверной. В VA `0x004F4268` функция загружает локальное значение `[EBP-0xC]` для последующих проверок; затем на обоих вариантах выхода EAX загружается из `[EBP+0x10]`. Поэтому Stage 3 использует DR3 не на caller continuation `0x000F7924`, а на внутреннем RVA `0x000F4268`.

В `0x000F4268` (до выполнения инструкции) трассировщик снимает:

- `matchedTableIndex_local_mC` = `[callee EBP-0x0C]` (0xFFFFFFFF, если индекс не установлен);
- `expectedReturnValue_arg3` = `[callee EBP+0x10]`, то значение, которое последующая ветка переносит в EAX перед `ret`;
- указатели arg4/arg5 из `[callee EBP+0x14]` / `[callee EBP+0x18]` и значения по этим указателям;
- сохранённый caller EBP из `[callee EBP]`, чтобы связать входной hit и внутренний финальный hit в пределах того же потока.

Это более точная трасса: entry breakpoint DR2 остаётся на `0x000F4030`, finalize breakpoint DR3 перенесён на `0x000F4268`. Логирование возврата больше не называет EAX индексом таблицы. Поля записи: `matchedTableIndex_local_mC`, `expectedReturnValue_arg3`, `out_arg4_flag`, `out_arg5_mappedValue`.


## Stage 4 — queue insertion observer (new experiment)

Static disassembly of `AALib.exe+0xF2DE0` (preferred VA `0x004F2DE0`) shows a small queue insertion helper. Its first six bytes are a complete, position-independent prologue: `55 8B EC 8B 45 08` (`push ebp; mov ebp,esp; mov eax,[ebp+8]`). The function reads queue pointer arg1, checks byte `[queue+0x0F]`, and if the guard is zero writes the 16-bit payload from arg3 to `[queue+4]`, event type from arg2 to `[queue+2]`, and updates queue flags at `[queue]`, `[queue+1]`, `[queue+6]`. It is cdecl-like; callers clean 12 bytes after return.

Call sites are numerous (138 static direct calls in the current full disassembly), so hooking all event streams would be noisy. Stage 4 filters at runtime to exact P1/P2 queue addresses derived from the known player object bases (`player + 0x3A2C`) and additionally verifies the corresponding CPU-control DWORD (`player + 0x3F2C`) is `1`. The hook records caller return RVA, side, event type, payload, queue guard before/after, active flag before/after, and stored type/payload after. Sites are aggregated in a fixed table; file writes are performed by a background worker.

The observer is installed by a six-byte inline detour with a trampoline. It refuses to install if the EXE fingerprint or the six-byte prologue differs. Existing code bytes are copied to the trampoline and executed before returning to `AALib.exe+0xF2DE6`. No debug registers or execution breakpoints are used. Other process threads are briefly suspended while the patch is applied.

**This is only an event-queue observer.** The helper is shared by many gameplay and scripted paths; the payload may be a transition, internal event, state command or a gameplay action. It is not yet established that any particular event is an attack ID or that a given callsite chooses the AI action. The next analysis step is to group CPU-only queue events by caller RVA and compare P1/P2 patterns, then trace the most relevant callsites upward toward the code that creates the event type/payload.

Build: Stage 4 adds `src/AIQueueTrace.cpp/.h` and includes the new translation unit in `Build.bat` and the Visual Studio project. Windows/MSVC compilation has not been performed in this environment; user-side build validation remains required.


## Stage 4 trace analysis and Stage 5 target

The user supplied a working Stage 4 `ArcanaAI_QueueTrace.log` from a COM-vs-COM session. The log contains many writer sites and event type/payload values. Important recurring writer caller return RVAs include `0x000F7C62`, `0x000F7CC5`, `0x000F265C`, `0x000F12DB`, `0x00127681`, and `0x00127691`.

Static disassembly maps:

- return RVA `0x000F7C62` to the call at VA `0x004F7C5D`, inside the per-player routine beginning at `0x004F7150`. Immediately before the write, this routine calls `0x004F3670` to obtain a value, then places that value into the event mailbox with type `1`. This is a strong command/event-generation candidate, but the payload is not yet proven to be an attack ID.
- return RVA `0x000F7CC5` to the adjacent type-0 mailbox write at VA `0x004F7CC0` in the same parent routine.
- return RVA `0x000F265C` to a type-2 write at VA `0x004F2657`; it computes the payload before insertion and then calls a timer helper.
- return RVA `0x00127681` / `0x00127691` to two adjacent writes in a different state handler: type 1, then type 2 with payload 3.
- return RVA `0x001581A0` is a type-2 write in a special handler that immediately calls the mailbox consumer at VA `0x005581A3`; this is one example where insertion and consumption happen close together.

The mailbox writer at VA `0x004F2DE0` has three arguments: queue pointer, event type, payload. It checks queue guard `[queue+0x0F]`; event type 1 or 2 sets pending byte `[queue]` to 1; special event type 0 with payload `0x1E` also sets it. It writes payload to `+0x04`, type to `+0x02`, clears `+0x06` and `+0x01`.

The consumer at VA `0x004F2E50` has two arguments (queue pointer and a metadata WORD). If current type/payload are not `0xFFFF`, it copies current payload/type into history `+0x0A`/`+0x08`, stores the metadata at `+0x0C`, resets current payload/type to `0xFFFF`, clears `+0x06`, `+0x01`, and guard `+0x0F`. It does not itself clear the active byte at `+0x00`; callers may update that separately. This confirms a one-slot mailbox with history, not a FIFO ring buffer.

The main processing method at VA `0x004EE480` checks whether current type/payload differ from history using `0x004F2E20`, snapshots them, calls the consumer `0x004F2E50`, sets the pending byte, then calls the dispatcher at VA `0x004EE200` with the previously captured type/payload. The dispatcher is called at return RVA `0x000EE5CB` in this path. Another direct call exists at VA `0x00532EFA` (return RVA `0x00132EFF`) with event type 2 and payload `0x19`.

Dispatcher `0x004EE200` is a `__thiscall` method with `ECX=player`, `arg1=eventType`, `arg2=payload`; it returns with `ret 8`. It branches on event type 0, 1, or 2, calling different mapping helpers (`0x00558560`, `0x0052EAC0`, and `0x005580B0`), then calls `0x00558EC0` with mapped values and the player object. The call sites do not use EAX as a return value, so the observer treats the return as void.

Stage 5 hooks `0x004EE200` with a 7-byte `__fastcall` detour that receives the original `this` pointer from ECX, ignores EDX, and receives the two stack arguments. It calls the original via a `__thiscall` trampoline. This calling-convention bridge and 7-byte stolen prologue have not yet been tested by the user in Windows; build and runtime testing are required. The observer records only exact P1/P2 object pointers whose control DWORD at `+0x3F2C` equals 1.

Interpretation caution: Stage 5 observes events after they are handed to a generic per-player dispatcher. It may include state transitions, scripted/system events, and gameplay actions. It does not by itself prove which events represent attacks or where the AI chooses them. The `queueHistoryMatchesArgs` field is included to check whether the history mailbox contents match the actual dispatcher arguments.


## Stage 7 — final type-1 command callsite snapshot

The Stage 7 target was checked directly against the supplied `AALib.exe`, not just against the previous text disassembly. The bytes at VA `0x004F7C59` are:

```asm
004F7C59  56                push esi
004F7C5A  6A 01             push 1
004F7C5C  53                push ebx
004F7C5D  E8 7E B1 FF FF    call 0x004F2DE0
004F7C62  8B 45 FC          mov eax,[ebp-4]
004F7C65  83 C4 0C          add esp,0x0C
```

The relative call destination resolves exactly to `AALib.exe+0xF2DE0`, the Stage 5 queue insertion helper. The parent routine starts at `AALib.exe+0xF7150`, reserves `0xD4` bytes of locals, and has saved nonvolatile registers below that local frame. At the target callsite, the relevant preserved registers are `EDI` (fighter/player object), `ESI` (payload value) and `EBX` (queue pointer). The three stack arguments at the callee entry are `[ESP+4]=queue`, `[ESP+8]=event type 1`, `[ESP+0xC]=payload`.

Stage 7 replaces only the five-byte CALL at RVA `0xF7C5D` with another relative CALL to a naked x86 shim. The shim uses `pushfd`/`pushad`, passes a snapshot to a C++ recorder, restores flags/registers, then tail-jumps to the original helper entry at RVA `0xF2DE0`. Because it does not introduce another return address in front of the original call frame, the helper's RET still returns to `0xF7C62`, and the caller retains its original `add esp,0x0C` cleanup. If Stage 5's global queue hook is active, the tail-jump enters that observer and then its trampoline; otherwise it enters the original game helper.

The Stage 7 recorder is filtered to the two exact player objects reconstructed from the confirmed COM control RVAs, CPU-control DWORD `player+0x3F2C == 1`, type 1, expected return RVA `0xF7C62`, and queue address `player+0x3A2C`. It captures the 53 DWORDs from `[EBP-0xD4]` through `[EBP-0x04]` plus the known player fields, then queues the record for a background writer. The record capacity is 4096; over-capacity records are counted and reported rather than overwriting previous samples.

The Stage 7 worker uses the same named patch-install mutex as Stage 5. The original call bytes and relative destination are verified before changing code. The hook sets its tail-jump destination before resuming suspended game threads to avoid a first-call race.

**Interpretation remains cautious:** `ESI` is definitely the payload passed to the generic mailbox helper at this callsite. The payload's semantic meaning (specific attack, command category, state or mapped action) still needs to be resolved by correlating the captured parent locals with Stage 5 queue/dispatch records and the game's character/action tables. Stage 7 is observational and does not change CPU decisions.


## Stage 7 runtime validation — 2026-11-08

Проверены свежие журналы Stage 7 из репозитория пользователя, относящиеся к сессии около `02:20:54`–`02:22:33`:

- `ArcanaAI_FinalCommandTrace.log`: 147 индивидуальных type-1 captures — P1: 56, P2: 91.
- Во всех 147 записях `payloadMatch=1`, `cpu=1`, `localsReadable=1`, `returnRVA=0xF7C62`.
- `parentEBP`, player pointer и queue pointer соответствуют ожидаемому родительскому frame и P1/P2 mailbox.
- После нормализации агрегированных `totalHits` из QueueTrace наборы Stage 7 и Stage 5 совпали **точно по side + payload**: 147 Stage 7 captures = 147 type-1 вызовов на `callerRVA=0xF7C62`. Различий не обнаружено.
- EventDispatchTrace содержит type-1 события с `queueHistoryMatchesArgs=1`.

Это подтверждает, что Stage 7 снимает фактический payload до входа в queue helper, а его callsite hook не теряет, не дублирует и не искажает наблюдаемые события. Это не доказывает, что payload является прямым ID атаки.

## Stage 8 — producer-context capture

Stage 8 оставляет Stage 5 и Stage 7 без изменений и добавляет `src/AIProducerContextTrace.cpp/.h`.

Цели выбраны по проверенному disassembly родительской функции `0x004F7150`:

```asm
004F79B1  call 0x004F34D0   ; caller return RVA 0x000F79B6
004F79E4  call 0x004F4360   ; unrelated helper
004F7A8A  call 0x004F34D0   ; caller return RVA 0x000F7A8F
004F7AD1  call 0x004F3930   ; caller return RVA 0x000F7AD6
```

Все три helper call sites передают пять cdecl-аргументов: player, `arg2`, `arg3`, указатель `out4` на parent `[EBP-0x08]`, указатель `out5` на parent `[EBP-0x04]`. F34D0 имеет пролог `55 8B EC 51 53`; F3930 — `55 8B EC 83 EC 18`.

Новый observer ставит entry detour на оба входа, проверяет fingerprint и байты прологов, создаёт trampoline с полным скопированным прологом и передаёт выполнение оригинальной функции. Низкоуровневый shim передаёт capture-wrapper-у первоначальный caller EBP из регистра EBP до исполнения оригинального пролога, исходный return address и исходные stack args. Wrapper вызывает оригинал, фиксирует EAX и значения out pointers до/после, parent locals и player fields. EAX оригинала возвращается caller-у.

Фильтр — только точные P1/P2 object pointers, CPU control DWORD `player+0x3F2C == 1` и следующие return RVAs: F34D0 `0xF79B6` / `0xF7A8F`; F3930 `0xF7AD6`. Это исключает нецелевые вызовы общих helper-ов.

Файл `ArcanaAI_ProducerContextTrace.log` пишется worker-потоком из фиксированного буфера на 2048 событий. На game thread нет файлового I/O. Записи включают tick/thread/time и `parentEBP`, чтобы можно было сопоставлять их с Stage 7 `FINAL_COMMAND` при одном и том же родительском frame.

Stage 8 остаётся observer-only: он не переписывает `arg2/arg3`, out pointer значения, EAX result или данные игрока. Runtime-проверка новой DLL ожидает подтверждения пользователя. В текущей среде новая translation unit прошла отдельную компиляцию clang-cl как i686 MSVC-compatible C++ с минимальными WinAPI заглушками; дизассемблирование объектного файла подтвердило x86 инструкции `pushfd/pushad`, корректные offsets исходного return address/args и восстановление сохранённого EAX. Это **не** является полной сборкой всей DLL под Windows SDK/MSVC.

## Stage 8 build correction — 2026-11-08

Пользовательская сборка под Visual Studio 18 Community / MSVC 14.51.36231 остановилась на двух ошибках C2488: `__declspec(naked)` был указан на forward declarations `ArcanaStage8HookF34D0` и `ArcanaStage8HookF3930`. Исправление: убрать `__declspec(naked)` только с объявлений; атрибут сохранён на телах обеих naked-функций, где он требуется для inline x86 assembly. Машинный код shim-ов после исправления подтверждён компиляцией clang-cl i686: `pushfd`, `pushal`, исходные stack offsets `+0x24/+0x28/+0x2C/+0x30/+0x34/+0x38`, вызов capture wrapper, очистка 0x1C байт, восстановление EAX в сохранённом слоте, `popal`, `popfd`, `ret`. Это проверка translation unit, не полная сборка DLL под MSVC/Windows SDK.


## Stage 9 — parent-flow helpers F3280 / F4360 / F4030

### Обоснование точек

В проверенном `AALib.exe` родительская процедура начинается по RVA `0xF7150`. На участке `0x4F79B1`–`0x4F79E9` после веток `F34D0` вызывает `F3280`, затем `F4360`:

```asm
004F79B1  call 0x004F34D0   ; return RVA F79B6
004F79CF  call 0x004F3280   ; return RVA F79D4
004F79E4  call 0x004F4360   ; return RVA F79E9
```

Ветка выше использует `F4030` по двум callsite-ам:

- `0x004F78DE`, return RVA `0xF78E3`;
- `0x004F7902`, return RVA `0xF7907`.

Из caller disassembly известно, что F3280/F4360/F4030 вызываются с пятью cdecl аргументами: player, `arg2`, `arg3`, `&[EBP-0x08]`, `&[EBP-0x04]`. Вызов F3280 расположен после F34D0; `ESI` (результат предыдущей ветки) передаётся третьим аргументом. После F3280 его `EAX` загружается в ESI; следующая F4360 получает обновлённый ESI. Это зафиксированная передача значений между callsite-ами, но семантика каждого helper ещё не утверждается.

### Stage 9 recorder

Новый `AIParentFlowTrace` сохраняет Stage 5/7/8. Он перехватывает только entry F3280, F4360, F4030 и фильтрует на точные callsite return RVA + точные P1/P2 CPU pointers. Проверенные прологи:

- F3280: `55 8B EC 83 EC 08`;
- F4030: `55 8B EC 83 EC 10`;
- F4360: `55 8B EC 83 EC 14`.

Для каждого совпадающего вызова записывается EAX, out4/out5 до/после, 53 parent locals `[EBP-0xD4..-0x04]` до/после и расширенный player snapshot. F4030 sampled separately per player, default 1/16, to avoid turning its repeated candidate probes into a high-volume trace. Sample interval is configurable 1..256.

The x86 naked shims use `pushfd/pushad`, capture the original caller EBP and stack arguments, call a recorder which invokes the original helper via a verified trampoline, restore the original registers/flags, and return the original EAX. File I/O occurs only on the worker thread. Buffer capacity is 2048 records; dropped records are reported.

### Аналитическая цель Stage 9

Сопоставить по стороне, parent EBP и tick:

1. предшествующий Stage 8 F34D0;
2. Stage 9 F3280 входные `arg2/arg3`, out4/out5 и EAX;
3. Stage 9 F4360 входные/выходные значения;
4. Stage 8 F3930 или ветку F4030;
5. Stage 7 FINAL_COMMAND payload и Stage 5 QueueTrace.

Отдельный интерес — команды, у которых в Stage 8 не было F34D0/F3930 с тем же tick/payload. Stage 9 проверит, не возникли ли они через F3280/F4360 либо ветку F4030.

Stage 9 is observer-only; it does not patch payloads, parent locals, player fields or helper return values. Runtime safety and full MSVC build still require the user's Build.log and in-game test.


## Stage 10 — all-caller helper observation and reusable queues

Stage 10 keeps the validated F34D0, F3930, F3280, F4030 and F4360 entry hooks, removes hard-coded caller-RVA filters, and retains the exact P1/P2 object plus CPU-control DWORD filter. Each event includes the absolute caller and module-relative callerRVA. All successful EAX results (anything except 0xFFFFFFFF) are recorded. Failures are sampled after the helper returns, 1/N by side/helper/caller-RVA hash bucket; first failure in each bucket is retained. This corrects Stage 9 F4030 pre-call sampling, which could skip successes.

Both modules use bounded reusable SRW-protected ring queues with 8192 records. The worker dequeues and frees each slot before file I/O; real saturation is counted. Sequence and QueryPerformanceCounter fields help order calls sharing a millisecond tick. Stage 10 remains observer-only; full MSVC build and in-game runtime validation remain user-side requirements.

### Correction from Stage 9 logs (2026-11-08)

Stage 8 emitted 15 buffer-full warnings totalling **182 dropped records**. Its monotonic 2048-entry array never reused slots after writing. Ten of seventy Stage 7 final commands lacked a Stage 8/9 record at the same side/tick; nine occurred after Stage 8 first reported a full buffer. The one pre-overflow unmatched command was P2 payload 0x02 at tick 744766375 (02:53:59.099). This remains a high-value Stage 10 correlation case, not proof by itself of another call path.


## Stage 11 — результаты Stage 10 и следующая диагностика (2026-11-08)

### Наблюдения Stage 10

Свежие логи относятся к прогону 03:37:01–03:37:43. Установились все три Parent Flow hooks (F3280/F4030/F4360) и оба Producer Context hooks (F34D0/F3930). Записано 193 PARENT_FLOW и 167 PRODUCER_CONTEXT; sequence непрерывна от 1 до последней записи, сообщений о переполнении нет.

В 15 тиках успешные результаты F3280 и F4360 совпали побитово для одной стороны; во всех таких парах результат F3280 совпал со входным arg3 F4360. Успешный F4030 дал 51 запись, и все 51 совпали со значением payload финальной команды того же игрока и тика. Это сильная корреляция, но не самостоятельное доказательство полной причинной цепочки.

### Найденный фильтр Stage 7

Старый Stage 7 recorder использовал сохранённый EDI как обязательный player pointer. Stage 5 QueueTrace независимо показывает вставки в точные очереди P1/P2 и содержит дополнительные type-1 caller RVA `0x127673`, `0xF6ADC`, `0x127681`. Поэтому EDI не следует использовать как фильтр стороны: значение регистра может не быть указателем игрока даже при передаче правильной очереди.

Stage 11 определяет сторону по `queueAddress == g_playerP1/P2 + 0x3A2C`, проверяет CPU DWORD реального player object и сохраняет исходный EDI отдельным полем `edi` / `ediMatchesPlayer`. Callsite остаётся строго `0xF7C5D`; это не превращает Stage 7 в глобальный hook.

### Подробная трассировка очереди

Stage 11 добавляет `QUEUE_EVENT_DETAIL` для каждого type-1 вызова вставки в одну из двух известных CPU-очередей. Запись содержит sequence, QPC, tick, caller address/RVA, сторону, queue/player pointers, тип/payload, состояние очереди до/после и до восьми stack addresses. Она выполняется в памяти на игровом потоке; файловый ввод-вывод остаётся в worker. Очередь ограничена 1024 записями, слот освобождается до записи в файл; потери считаются и выводятся предупреждением.

Это должно дать точную контекстную запись для P2 payload `0x21` и `0x26`, а также для type-1 caller RVA `0x127673`, `0xF6ADC` и `0x127681`. Stack addresses — диагностический контекст; их нужно сопоставлять с тем же AALib.exe image/fingerprint.

### Проверка и ограничения

Это Stage 11 source-only диагностическое изменение. MSVC build и runtime не выполнялись в этой среде. До получения нового Build.log и новых логов нельзя утверждать, что хук компилируется, устанавливается в игре или что все вставки Stage 5 будут соответствовать Stage 7. Stage 10 source/archive и ветка остаются нетронутыми.
