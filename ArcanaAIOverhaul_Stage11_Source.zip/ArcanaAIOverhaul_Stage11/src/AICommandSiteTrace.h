#pragma once

#include <Windows.h>

void StartAICommandSiteTrace(HMODULE proxyModule);
