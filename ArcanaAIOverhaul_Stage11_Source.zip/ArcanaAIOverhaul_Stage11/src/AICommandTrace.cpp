#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <TlHelp32.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cwchar>

#include "AICommandTrace.h"
#include "ComVsCom.h"

namespace
{
    constexpr DWORD kP1ControlRva = 0x0DCA5EA4;
    constexpr DWORD kP2ControlRva = 0x0DCD0BCC;
    constexpr DWORD kPlayerControlOffset = 0x3F2C;

    // Static disassembly of the exact AALib.exe supplied for this project:
    // 0x4F4030 is called from 0x4F78DE and 0x4F7902.
    // 0x4F4268 is the common internal finalization point before the helper returns.
    constexpr DWORD kCommandResolverEntryRva = 0x000F4030;
    constexpr DWORD kCommandResolverFinalizeRva = 0x000F4268;
    constexpr DWORD kCallerOneReturnRva = 0x000F78E3;
    constexpr DWORD kCallerTwoReturnRva = 0x000F7907;

    constexpr DWORD kDefaultScanIntervalMs = 250;
    constexpr DWORD kMinimumScanIntervalMs = 50;
    constexpr DWORD kMaximumScanIntervalMs = 2000;
    constexpr DWORD kTrackedThreadCapacity = 256;
    constexpr LONG kCommandSiteCount = 128;

    enum : DWORD
    {
        kSampleEntry = 1,
        kSampleFinalize = 2
    };

    struct CommandSite
    {
        // State: 0 = empty, -1 = being initialized, 1 = ready.
        volatile LONG State;
        volatile LONG Count;
        volatile LONG Reported;
        DWORD Kind;
        DWORD Side;
        DWORD ThreadId;
        DWORD PlayerObject;
        DWORD CallerRva;
        DWORD Arg2;
        DWORD Arg3;
        DWORD Arg4;
        DWORD Arg5;
        DWORD PreOutA;
        DWORD PreOutB;
        DWORD MatchedIndex;
        DWORD ReturnValue;
        DWORD OutA;
        DWORD OutB;
        DWORD Eax;
        DWORD Ebx;
        DWORD Ecx;
        DWORD Edx;
        DWORD Esi;
        DWORD Edi;
        DWORD Ebp;
        DWORD Esp;
    };

    struct PendingCall
    {
        volatile LONG ThreadId;
        volatile LONG Pending;
        DWORD CallerEbp;
        DWORD Side;
        DWORD CallerRva;
        DWORD PlayerObject;
        DWORD Arg2;
        DWORD Arg3;
        DWORD Arg4;
        DWORD Arg5;
        DWORD PreOutA;
        DWORD PreOutB;
    };

    struct TrackedThread
    {
        DWORD Id;
        HANDLE Handle;
        bool BreakpointsInstalled;
    };

    CommandSite g_sites[2][kCommandSiteCount]{};
    PendingCall g_pendingCalls[kTrackedThreadCapacity]{};
    TrackedThread g_trackedThreads[kTrackedThreadCapacity]{};

    INIT_ONCE g_startOnce = INIT_ONCE_STATIC_INIT;
    HMODULE g_proxyModule = nullptr;
    HMODULE g_gameModule = nullptr;
    PVOID g_vectoredHandler = nullptr;

    DWORD g_gameBase = 0;
    DWORD g_gameImageSize = 0;
    DWORD g_playerP1 = 0;
    DWORD g_playerP2 = 0;
    DWORD g_commandEntry = 0;
    DWORD g_commandFinalize = 0;
    DWORD g_scanIntervalMs = kDefaultScanIntervalMs;

    volatile LONG g_firstInstallLog = 0;
    volatile LONG g_noInstallLog = 0;
    volatile LONG g_capacityWarningLogged = 0;
    volatile LONG g_droppedSites = 0;

    bool GetSiblingPath(wchar_t* output, DWORD capacity, const wchar_t* filename)
    {
        if (output == nullptr || capacity == 0 || filename == nullptr || g_proxyModule == nullptr)
        {
            return false;
        }

        const DWORD length = GetModuleFileNameW(g_proxyModule, output, capacity);
        if (length == 0 || length >= capacity)
        {
            return false;
        }

        wchar_t* slash = wcsrchr(output, L'\\');
        wchar_t* forwardSlash = wcsrchr(output, L'/');
        if (forwardSlash != nullptr && (slash == nullptr || forwardSlash > slash))
        {
            slash = forwardSlash;
        }
        if (slash == nullptr)
        {
            return false;
        }

        *(slash + 1) = L'\0';
        const std::size_t used = wcslen(output);
        const std::size_t nameLength = wcslen(filename);
        if (used + nameLength + 1 > capacity)
        {
            return false;
        }
        wcscat_s(output, capacity, filename);
        return true;
    }

    void AppendCommandLog(const char* message)
    {
        wchar_t logPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(logPath, MAX_PATH, L"ArcanaAI_CommandTrace.log"))
        {
            return;
        }

        SYSTEMTIME now{};
        GetLocalTime(&now);
        char line[2048]{};
        const int count = sprintf_s(
            line,
            "[%04u-%02u-%02u %02u:%02u:%02u] %s\r\n",
            now.wYear, now.wMonth, now.wDay,
            now.wHour, now.wMinute, now.wSecond,
            message != nullptr ? message : "(empty)");
        if (count <= 0)
        {
            return;
        }

        HANDLE file = CreateFileW(
            logPath,
            FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            nullptr);
        if (file == INVALID_HANDLE_VALUE)
        {
            return;
        }

        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(count), &written, nullptr);
        CloseHandle(file);
    }

    int ReadIniInt(const wchar_t* section, const wchar_t* key, int defaultValue)
    {
        wchar_t iniPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(iniPath, MAX_PATH, L"ArcanaAI.ini"))
        {
            return defaultValue;
        }
        return GetPrivateProfileIntW(section, key, defaultValue, iniPath);
    }

    bool GetImageFingerprint32(HMODULE module, DWORD* imageSize, DWORD* timeDateStamp)
    {
        if (module == nullptr || imageSize == nullptr || timeDateStamp == nullptr)
        {
            return false;
        }

        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(module);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0)
        {
            return false;
        }

        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(
            reinterpret_cast<const BYTE*>(module) + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC)
        {
            return false;
        }
        *imageSize = nt->OptionalHeader.SizeOfImage;
        *timeDateStamp = nt->FileHeader.TimeDateStamp;
        return true;
    }

    bool IsGameImageAddress(DWORD address)
    {
        return g_gameBase != 0 && g_gameImageSize != 0 &&
            address >= g_gameBase + 0x1000 && address - g_gameBase < g_gameImageSize;
    }

    bool SafeReadDword(DWORD address, DWORD* value)
    {
        if (address == 0 || value == nullptr)
        {
            return false;
        }
        __try
        {
            *value = *reinterpret_cast<const volatile DWORD*>(address);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *value = 0;
            return false;
        }
    }

    DWORD GetSideFromPlayerObject(DWORD object)
    {
        if (object == g_playerP1) return 1;
        if (object == g_playerP2) return 2;
        return 0;
    }

    PendingCall* GetPendingCall(DWORD threadId, bool create)
    {
        for (DWORD i = 0; i < kTrackedThreadCapacity; ++i)
        {
            PendingCall& item = g_pendingCalls[i];
            const LONG current = InterlockedCompareExchange(&item.ThreadId, 0, 0);
            if (static_cast<DWORD>(current) == threadId)
            {
                return &item;
            }
            if (current == 0 && create &&
                InterlockedCompareExchange(&item.ThreadId, static_cast<LONG>(threadId), 0) == 0)
            {
                return &item;
            }
        }
        return nullptr;
    }

    bool SameSiteKey(const CommandSite& site, DWORD kind, DWORD side,
        DWORD callerRva, DWORD arg2, DWORD arg3, DWORD matchedIndex, DWORD returnValue, DWORD outA, DWORD outB)
    {
        if (site.Kind != kind || site.Side != side || site.CallerRva != callerRva ||
            site.Arg2 != arg2 || site.Arg3 != arg3)
        {
            return false;
        }
        if (kind == kSampleFinalize)
        {
            return site.MatchedIndex == matchedIndex && site.ReturnValue == returnValue && site.OutA == outA && site.OutB == outB;
        }
        return true;
    }

    void AddCommandSite(DWORD kind, DWORD side, DWORD threadId, DWORD callerRva,
        DWORD playerObject, DWORD arg2, DWORD arg3, DWORD arg4, DWORD arg5,
        DWORD preOutA, DWORD preOutB, DWORD matchedIndex, DWORD returnValue, DWORD outA, DWORD outB,
        const CONTEXT* context)
    {
        if (context == nullptr)
        {
            return;
        }

        DWORD hash = callerRva ^ (arg2 * 0x9E3779B9u) ^ (arg3 * 0x85EBCA6Bu) ^ (side << 24);
        if (kind == kSampleFinalize)
        {
            hash ^= matchedIndex * 0x27D4EB2Du;
            hash ^= returnValue * 0xC2B2AE35u;
            hash ^= outA + (outB << 1);
        }
        const DWORD start = hash % static_cast<DWORD>(kCommandSiteCount);

        for (DWORD probe = 0; probe < static_cast<DWORD>(kCommandSiteCount); ++probe)
        {
            CommandSite& site = g_sites[kind == kSampleEntry ? 0 : 1][(start + probe) % kCommandSiteCount];
            const LONG state = InterlockedCompareExchange(&site.State, 0, 0);
            if (state == 1 && SameSiteKey(site, kind, side, callerRva, arg2, arg3, matchedIndex, returnValue, outA, outB))
            {
                InterlockedIncrement(&site.Count);
                return;
            }

            if (state == 0 && InterlockedCompareExchange(&site.State, -1, 0) == 0)
            {
                site.Kind = kind;
                site.Side = side;
                site.ThreadId = threadId;
                site.PlayerObject = playerObject;
                site.CallerRva = callerRva;
                site.Arg2 = arg2;
                site.Arg3 = arg3;
                site.Arg4 = arg4;
                site.Arg5 = arg5;
                site.PreOutA = preOutA;
                site.PreOutB = preOutB;
                site.MatchedIndex = matchedIndex;
                site.ReturnValue = returnValue;
                site.OutA = outA;
                site.OutB = outB;
                site.Eax = context->Eax;
                site.Ebx = context->Ebx;
                site.Ecx = context->Ecx;
                site.Edx = context->Edx;
                site.Esi = context->Esi;
                site.Edi = context->Edi;
                site.Ebp = context->Ebp;
                site.Esp = context->Esp;
                InterlockedExchange(&site.Count, 1);
                InterlockedExchange(&site.State, 1);
                return;
            }
        }

        InterlockedIncrement(&g_droppedSites);
    }

    void CaptureCommandResolverEntry(PCONTEXT context)
    {
        if (context == nullptr || context->Esp == 0)
        {
            return;
        }

        DWORD stack[6]{};
        __try
        {
            const DWORD* source = reinterpret_cast<const DWORD*>(context->Esp);
            for (int i = 0; i < 6; ++i)
            {
                stack[i] = source[i];
            }
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            return;
        }

        if (stack[0] < g_gameBase)
        {
            return;
        }
        const DWORD callerRva = stack[0] - g_gameBase;
        if (callerRva != kCallerOneReturnRva && callerRva != kCallerTwoReturnRva)
        {
            // The static binary contains two direct call sites. Ignore any
            // unexpected caller until it is independently verified.
            return;
        }

        const DWORD playerObject = stack[1];
        const DWORD side = GetSideFromPlayerObject(playerObject);
        DWORD preOutA = 0;
        DWORD preOutB = 0;
        SafeReadDword(stack[4], &preOutA);
        SafeReadDword(stack[5], &preOutB);

        const DWORD threadId = GetCurrentThreadId();
        PendingCall* pending = GetPendingCall(threadId, true);
        if (pending != nullptr)
        {
            InterlockedExchange(&pending->Pending, 0);
            pending->CallerEbp = context->Ebp;
            pending->Side = side;
            pending->CallerRva = callerRva;
            pending->PlayerObject = playerObject;
            pending->Arg2 = stack[2];
            pending->Arg3 = stack[3];
            pending->Arg4 = stack[4];
            pending->Arg5 = stack[5];
            pending->PreOutA = preOutA;
            pending->PreOutB = preOutB;
            MemoryBarrier();
            InterlockedExchange(&pending->Pending, 1);
        }

        AddCommandSite(
            kSampleEntry, side, threadId, callerRva, playerObject,
            stack[2], stack[3], stack[4], stack[5], preOutA, preOutB,
            0xFFFFFFFFu, 0, 0, 0, context);
    }

    void CaptureCommandResolverFinalize(PCONTEXT context)
    {
        if (context == nullptr || context->Ebp < 0x20)
        {
            return;
        }

        PendingCall* pending = GetPendingCall(GetCurrentThreadId(), false);
        if (pending == nullptr || InterlockedCompareExchange(&pending->Pending, 0, 0) == 0)
        {
            return;
        }

        // At this internal point EBP belongs to the resolver. [EBP] is the
        // caller's saved EBP; use it to pair this sample with the entry hit.
        DWORD savedCallerEbp = 0;
        if (!SafeReadDword(context->Ebp, &savedCallerEbp) || savedCallerEbp != pending->CallerEbp)
        {
            return;
        }

        DWORD matchedIndex = 0xFFFFFFFFu;
        DWORD returnValue = 0;
        DWORD arg4Pointer = 0;
        DWORD arg5Pointer = 0;
        SafeReadDword(context->Ebp - 0x0C, &matchedIndex);
        SafeReadDword(context->Ebp + 0x10, &returnValue);
        SafeReadDword(context->Ebp + 0x14, &arg4Pointer);
        SafeReadDword(context->Ebp + 0x18, &arg5Pointer);

        DWORD outA = 0;
        DWORD outB = 0;
        SafeReadDword(arg4Pointer, &outA);
        SafeReadDword(arg5Pointer, &outB);
        InterlockedExchange(&pending->Pending, 0);

        AddCommandSite(
            kSampleFinalize, pending->Side, GetCurrentThreadId(), pending->CallerRva,
            pending->PlayerObject, pending->Arg2, pending->Arg3,
            pending->Arg4, pending->Arg5, pending->PreOutA, pending->PreOutB,
            matchedIndex, returnValue, outA, outB, context);
    }

    LONG CALLBACK CommandTraceExceptionHandler(EXCEPTION_POINTERS* exceptionInfo)
    {
        if (exceptionInfo == nullptr || exceptionInfo->ExceptionRecord == nullptr ||
            exceptionInfo->ContextRecord == nullptr ||
            exceptionInfo->ExceptionRecord->ExceptionCode != EXCEPTION_SINGLE_STEP)
        {
            return EXCEPTION_CONTINUE_SEARCH;
        }

        PCONTEXT context = exceptionInfo->ContextRecord;
        const DWORD dr6 = context->Dr6;
        const DWORD ourHits = dr6 & 0xCu; // DR2 = entry, DR3 = resolver internal finalization.
        if (ourHits == 0)
        {
            return EXCEPTION_CONTINUE_SEARCH;
        }

        if ((ourHits & 0x4u) != 0 && context->Eip == g_commandEntry)
        {
            CaptureCommandResolverEntry(context);
        }
        if ((ourHits & 0x8u) != 0 && context->Eip == g_commandFinalize)
        {
            CaptureCommandResolverFinalize(context);
        }

        // Clear only DR2/DR3 status bits owned by this tracer. If another
        // debugger/watchpoint fired at the same time, leave its status intact
        // and let the next VEH handler process it.
        context->Dr6 &= ~0xCu;
        const DWORD foreignHits = context->Dr6 & (0x3u | 0xE000u);
        return foreignHits == 0 ? EXCEPTION_CONTINUE_EXECUTION : EXCEPTION_CONTINUE_SEARCH;
    }

    bool IsOurActionBreakpointConfiguration(const CONTEXT& context)
    {
        return context.Dr2 == g_commandEntry &&
            context.Dr3 == g_commandFinalize &&
            (context.Dr7 & 0xFF0000F0u) == 0x00000050u;
    }

    void PruneTrackedThreads()
    {
        for (DWORD i = 0; i < kTrackedThreadCapacity; ++i)
        {
            TrackedThread& slot = g_trackedThreads[i];
            if (slot.Handle != nullptr && WaitForSingleObject(slot.Handle, 0) == WAIT_OBJECT_0)
            {
                CloseHandle(slot.Handle);
                slot = {};
            }
        }
    }

    bool IsThreadTracked(DWORD threadId)
    {
        for (DWORD i = 0; i < kTrackedThreadCapacity; ++i)
        {
            if (g_trackedThreads[i].Handle != nullptr && g_trackedThreads[i].Id == threadId)
            {
                return true;
            }
        }
        return false;
    }

    bool InspectThreadAndKeepHandle(DWORD threadId, HANDLE* retainedHandle, bool* breakpointsInstalled)
    {
        if (retainedHandle == nullptr || breakpointsInstalled == nullptr || threadId == GetCurrentThreadId())
        {
            return false;
        }

        *retainedHandle = nullptr;
        *breakpointsInstalled = false;

        HANDLE thread = OpenThread(
            THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_SET_CONTEXT |
                THREAD_QUERY_INFORMATION | SYNCHRONIZE,
            FALSE,
            threadId);
        if (thread == nullptr)
        {
            return false;
        }

        bool inspected = false;
        bool installed = false;
        const DWORD suspendResult = SuspendThread(thread);
        if (suspendResult != static_cast<DWORD>(-1))
        {
            CONTEXT context{};
            context.ContextFlags = CONTEXT_DEBUG_REGISTERS;
            if (GetThreadContext(thread, &context))
            {
                inspected = true;
                if (IsOurActionBreakpointConfiguration(context))
                {
                    installed = true;
                }
                else
                {
                    // DR2/DR3 are used only when both slots are entirely free.
                    // Never overwrite another debugger's addresses/configuration.
                    const bool enableBitsFree = (context.Dr7 & 0xF0u) == 0;
                    const bool configBitsFree = (context.Dr7 & 0xFF000000u) == 0;
                    if (enableBitsFree && configBitsFree)
                    {
                        context.Dr2 = g_commandEntry;
                        context.Dr3 = g_commandFinalize;
                        context.Dr6 &= ~0xCu;
                        // DR2 and DR3: local enable, execution breakpoint (RW=00), length=1 (LEN=00).
                        context.Dr7 = (context.Dr7 & ~0xFF0000F0u) | 0x00000050u;
                        installed = SetThreadContext(thread, &context) != FALSE;
                    }
                }
            }
            ResumeThread(thread);
        }

        if (!inspected)
        {
            CloseHandle(thread);
            return false;
        }

        *retainedHandle = thread;
        *breakpointsInstalled = installed;
        return true;
    }

    DWORD InstallBreakpointsOnCurrentThreads()
    {
        const DWORD processId = GetCurrentProcessId();
        const DWORD currentThreadId = GetCurrentThreadId();
        const DWORD comThreadId = GetComVsComThreadId();
        DWORD newlyInspected = 0;
        DWORD newlyInstalled = 0;
        PruneTrackedThreads();

        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
        {
            return 0;
        }

        THREADENTRY32 entry{};
        entry.dwSize = sizeof(entry);
        if (Thread32First(snapshot, &entry))
        {
            do
            {
                if (entry.th32OwnerProcessID == processId &&
                    entry.th32ThreadID != currentThreadId &&
                    entry.th32ThreadID != comThreadId &&
                    !IsThreadTracked(entry.th32ThreadID))
                {
                    HANDLE retainedHandle = nullptr;
                    bool breakpointsInstalled = false;
                    if (InspectThreadAndKeepHandle(entry.th32ThreadID, &retainedHandle, &breakpointsInstalled))
                    {
                        bool stored = false;
                        for (DWORD index = 0; index < kTrackedThreadCapacity; ++index)
                        {
                            TrackedThread& slot = g_trackedThreads[index];
                            if (slot.Handle == nullptr)
                            {
                                slot.Id = entry.th32ThreadID;
                                slot.Handle = retainedHandle;
                                slot.BreakpointsInstalled = breakpointsInstalled;
                                stored = true;
                                ++newlyInspected;
                                if (breakpointsInstalled) ++newlyInstalled;
                                break;
                            }
                        }

                        if (!stored)
                        {
                            CloseHandle(retainedHandle);
                            if (InterlockedCompareExchange(&g_capacityWarningLogged, 1, 0) == 0)
                            {
                                AppendCommandLog("WARNING: tracked-thread capacity reached; additional threads will not be traced.");
                            }
                        }
                    }
                }
                entry.dwSize = sizeof(entry);
            } while (Thread32Next(snapshot, &entry));
        }

        CloseHandle(snapshot);
        if (newlyInspected != 0 && newlyInstalled != 0 &&
            InterlockedCompareExchange(&g_firstInstallLog, 1, 0) == 0)
        {
            char message[256]{};
            sprintf_s(message,
                "Command-resolver execution breakpoints installed on %lu game thread(s); inspected %lu. New threads will be checked automatically.",
                static_cast<unsigned long>(newlyInstalled),
                static_cast<unsigned long>(newlyInspected));
            AppendCommandLog(message);
        }
        else if (newlyInspected != 0 && newlyInstalled == 0 &&
            InterlockedCompareExchange(&g_noInstallLog, 1, 0) == 0)
        {
            AppendCommandLog("Game threads were inspected, but DR2/DR3 were occupied or unavailable. Existing debug-register owners were left untouched; scanning continues for new threads.");
        }
        return newlyInstalled;
    }

    void FlushCommandSites()
    {
        for (int kindIndex = 0; kindIndex < 2; ++kindIndex)
        {
            for (LONG index = 0; index < kCommandSiteCount; ++index)
            {
                CommandSite& site = g_sites[kindIndex][index];
                if (InterlockedCompareExchange(&site.State, 0, 0) != 1 ||
                    InterlockedCompareExchange(&site.Reported, 1, 0) != 0)
                {
                    continue;
                }

                char message[1536]{};
                const char* side = site.Side == 1 ? "P1" : (site.Side == 2 ? "P2" : "UNKNOWN");
                const LONG hits = InterlockedCompareExchange(&site.Count, 0, 0);
                if (site.Kind == kSampleEntry)
                {
                    sprintf_s(message,
                        "ACTION_RESOLVE_ENTER side=%s tid=%lu callerRVA=0x%08lX player=0x%08lX arg2=0x%08lX arg3=0x%08lX arg4_out_ptr=0x%08lX arg5_out_ptr=0x%08lX pre_outA=0x%08lX pre_outB=0x%08lX hits=%ld EAX=%08lX EBX=%08lX ECX=%08lX EDX=%08lX ESI=%08lX EDI=%08lX EBP=%08lX ESP=%08lX",
                        side,
                        static_cast<unsigned long>(site.ThreadId),
                        static_cast<unsigned long>(site.CallerRva),
                        static_cast<unsigned long>(site.PlayerObject),
                        static_cast<unsigned long>(site.Arg2),
                        static_cast<unsigned long>(site.Arg3),
                        static_cast<unsigned long>(site.Arg4),
                        static_cast<unsigned long>(site.Arg5),
                        static_cast<unsigned long>(site.PreOutA),
                        static_cast<unsigned long>(site.PreOutB),
                        static_cast<long>(hits),
                        static_cast<unsigned long>(site.Eax),
                        static_cast<unsigned long>(site.Ebx),
                        static_cast<unsigned long>(site.Ecx),
                        static_cast<unsigned long>(site.Edx),
                        static_cast<unsigned long>(site.Esi),
                        static_cast<unsigned long>(site.Edi),
                        static_cast<unsigned long>(site.Ebp),
                        static_cast<unsigned long>(site.Esp));
                }
                else
                {
                    sprintf_s(message,
                        "ACTION_RESOLVE_FINALIZE side=%s tid=%lu callerRVA=0x%08lX player=0x%08lX arg2_candidate=0x%08lX arg3_initial=0x%08lX arg4_out_ptr=0x%08lX arg5_out_ptr=0x%08lX pre_outA=0x%08lX pre_outB=0x%08lX matchedTableIndex_local_mC=0x%08lX expectedReturnValue_arg3=0x%08lX out_arg4_flag=0x%08lX out_arg5_mappedValue=0x%08lX hits=%ld ESI=%08lX EDI=%08lX EBP=%08lX ESP=%08lX",
                        side,
                        static_cast<unsigned long>(site.ThreadId),
                        static_cast<unsigned long>(site.CallerRva),
                        static_cast<unsigned long>(site.PlayerObject),
                        static_cast<unsigned long>(site.Arg2),
                        static_cast<unsigned long>(site.Arg3),
                        static_cast<unsigned long>(site.Arg4),
                        static_cast<unsigned long>(site.Arg5),
                        static_cast<unsigned long>(site.PreOutA),
                        static_cast<unsigned long>(site.PreOutB),
                        static_cast<unsigned long>(site.MatchedIndex),
                        static_cast<unsigned long>(site.ReturnValue),
                        static_cast<unsigned long>(site.OutA),
                        static_cast<unsigned long>(site.OutB),
                        static_cast<long>(hits),
                        static_cast<unsigned long>(site.Esi),
                        static_cast<unsigned long>(site.Edi),
                        static_cast<unsigned long>(site.Ebp),
                        static_cast<unsigned long>(site.Esp));
                }
                AppendCommandLog(message);
            }
        }

        const LONG dropped = InterlockedCompareExchange(&g_droppedSites, 0, 0);
        if (dropped != 0)
        {
            char message[160]{};
            sprintf_s(message, "WARNING: %ld additional unique command trace samples could not be stored (site table full).", static_cast<long>(dropped));
            AppendCommandLog(message);
            InterlockedExchange(&g_droppedSites, 0);
        }
    }

    DWORD WINAPI CommandTraceThread(void*)
    {
        const int enabled = ReadIniInt(L"AIResearch", L"EnableCommandResolveTrace", 0);
        int interval = ReadIniInt(L"AIResearch", L"CommandTraceScanIntervalMs", static_cast<int>(kDefaultScanIntervalMs));
        if (interval < static_cast<int>(kMinimumScanIntervalMs)) interval = static_cast<int>(kMinimumScanIntervalMs);
        if (interval > static_cast<int>(kMaximumScanIntervalMs)) interval = static_cast<int>(kMaximumScanIntervalMs);
        g_scanIntervalMs = static_cast<DWORD>(interval);

        if (enabled == 0)
        {
            AppendCommandLog("Command-resolver trace is disabled in ArcanaAI.ini. No execution breakpoints were installed.");
            return 0;
        }

        for (int attempt = 0; attempt < 300 && g_gameModule == nullptr; ++attempt)
        {
            g_gameModule = GetModuleHandleW(L"AALib.exe");
            if (g_gameModule == nullptr) Sleep(100);
        }
        if (g_gameModule == nullptr)
        {
            AppendCommandLog("ERROR: AALib.exe was not found; command-resolver trace stopped.");
            return 0;
        }

        g_gameBase = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(g_gameModule));
        DWORD imageTimeDateStamp = 0;
        if (!GetImageFingerprint32(g_gameModule, &g_gameImageSize, &imageTimeDateStamp) ||
            g_gameImageSize != 0x0E0EB000u || imageTimeDateStamp != 0x5FE5AA91u ||
            kCommandResolverEntryRva >= g_gameImageSize ||
            kCommandResolverFinalizeRva >= g_gameImageSize ||
            kP1ControlRva < kPlayerControlOffset ||
            kP2ControlRva < kPlayerControlOffset)
        {
            AppendCommandLog("ERROR: AALib.exe PE fingerprint does not match the analyzed build (expected SizeOfImage=0x0E0EB000, TimeDateStamp=0x5FE5AA91). No execution breakpoints were installed.");
            return 0;
        }

        g_playerP1 = g_gameBase + kP1ControlRva - kPlayerControlOffset;
        g_playerP2 = g_gameBase + kP2ControlRva - kPlayerControlOffset;
        g_commandEntry = g_gameBase + kCommandResolverEntryRva;
        g_commandFinalize = g_gameBase + kCommandResolverFinalizeRva;

        DWORD comThreadId = 0;
        for (int attempt = 0; attempt < 100 && comThreadId == 0; ++attempt)
        {
            comThreadId = GetComVsComThreadId();
            if (comThreadId == 0) Sleep(20);
        }
        if (comThreadId == 0)
        {
            AppendCommandLog("ERROR: COMvsCOM thread ID was not published; tracer stopped to avoid scanning its writer thread.");
            return 0;
        }

        if (g_vectoredHandler == nullptr)
        {
            g_vectoredHandler = AddVectoredExceptionHandler(1, CommandTraceExceptionHandler);
        }
        if (g_vectoredHandler == nullptr)
        {
            AppendCommandLog("ERROR: AddVectoredExceptionHandler failed; command-resolver trace stopped.");
            return 0;
        }

        char start[640]{};
        sprintf_s(start,
            "Command-resolver trace active. DR2 entry RVA=0x%08lX, DR3 internal-finalize RVA=0x%08lX; player objects P1=0x%08lX P2=0x%08lX; scan=%lu ms; COMvsCOM writer TID=%lu excluded. DR2/DR3 owners are never overwritten.",
            static_cast<unsigned long>(kCommandResolverEntryRva),
            static_cast<unsigned long>(kCommandResolverFinalizeRva),
            static_cast<unsigned long>(g_playerP1),
            static_cast<unsigned long>(g_playerP2),
            static_cast<unsigned long>(g_scanIntervalMs),
            static_cast<unsigned long>(comThreadId));
        AppendCommandLog(start);

        for (;;)
        {
            InstallBreakpointsOnCurrentThreads();
            FlushCommandSites();
            Sleep(g_scanIntervalMs);
        }
    }

    BOOL CALLBACK StartCommandTraceWorker(PINIT_ONCE, PVOID, PVOID*)
    {
        HANDLE thread = CreateThread(nullptr, 0, CommandTraceThread, nullptr, 0, nullptr);
        if (thread == nullptr)
        {
            AppendCommandLog("ERROR: failed to create command-resolver trace worker thread.");
            return TRUE;
        }
        CloseHandle(thread);
        return TRUE;
    }
}

void StartAICommandTrace(HMODULE proxyModule)
{
    if (proxyModule != nullptr)
    {
        g_proxyModule = proxyModule;
    }
    InitOnceExecuteOnce(&g_startOnce, StartCommandTraceWorker, nullptr, nullptr);
}
