#pragma once

#include <Windows.h>

// Optional diagnostic tracing for the command-resolution helper at AALib.exe+0xF4030.
// Uses DR2/DR3 execution breakpoints and does not modify game code or decisions.
void StartAICommandTrace(HMODULE proxyModule);
