#pragma once
#include <Windows.h>
void StartAIParentFlowTrace(HMODULE proxyModule);
