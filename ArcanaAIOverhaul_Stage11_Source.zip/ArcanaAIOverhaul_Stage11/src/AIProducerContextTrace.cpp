#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <TlHelp32.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <cwchar>

#include "AIProducerContextTrace.h"

extern "C" int __cdecl ArcanaStage10CaptureF34D0(
    void* player, DWORD arg2, DWORD arg3, DWORD* out4, DWORD* out5,
    DWORD callerAddress, DWORD parentEbp);
extern "C" int __cdecl ArcanaStage10CaptureF3930(
    void* player, DWORD arg2, DWORD arg3, DWORD* out4, DWORD* out5,
    DWORD callerAddress, DWORD parentEbp);
// Keep forward declarations free of __declspec(naked): MSVC accepts the
// attribute on the function definitions below, not on a standalone declaration.
extern "C" int ArcanaStage10HookF34D0();
extern "C" int ArcanaStage10HookF3930();

// Both entry shims replace only complete x86 prologues. They capture the
// original caller EBP/return address/arguments, call the original function
// through a trampoline, then return its exact EAX result to the game.
namespace
{
    constexpr DWORD kExpectedImageSize = 0x0E0EB000u;
    constexpr DWORD kExpectedTimeDateStamp = 0x5FE5AA91u;

    constexpr DWORD kP1ControlRva = 0x0DCA5EA4u;
    constexpr DWORD kP2ControlRva = 0x0DCD0BCCu;
    constexpr DWORD kPlayerControlOffset = 0x3F2Cu;

    constexpr DWORD kRvaF34D0 = 0x000F34D0u;
    constexpr DWORD kRvaF3930 = 0x000F3930u;
    constexpr DWORD kCallerF34D0A = 0x000F79B6u;
    constexpr DWORD kCallerF34D0B = 0x000F7A8Fu;
    constexpr DWORD kCallerF3930 = 0x000F7AD6u;

    constexpr DWORD kFlushIntervalDefaultMs = 250u;
    constexpr DWORD kFlushIntervalMinMs = 100u;
    constexpr DWORD kFlushIntervalMaxMs = 5000u;
    constexpr DWORD kRecordCapacity = 8192u;
    constexpr DWORD kFailedSampleIntervalDefault = 16u;
    constexpr DWORD kParentLocalBytes = 0xD4u;
    constexpr DWORD kParentLocalCount = kParentLocalBytes / sizeof(DWORD);

    enum class HelperId : DWORD
    {
        F34D0 = 1,
        F3930 = 2
    };

    using Helper5Fn = int(__cdecl*)(void*, DWORD, DWORD, DWORD*, DWORD*);

    struct PlayerSnapshot
    {
        DWORD CpuControl;
        WORD Field3A34;
        WORD Field3A36;
        DWORD Field3F20;
        DWORD Field3F30;
        DWORD Field3F78;
        DWORD Field3A70;
        DWORD Field3A74;
        DWORD Field3A78;
        DWORD Field3B70;
        DWORD Field3B74;
        DWORD Field3B90;
        DWORD Field3B78;
        DWORD Field3B7C;
        DWORD Field3B80;
        DWORD Field3B84;
        DWORD Field3B88;
        DWORD Field3F50;
        DWORD Field3F58;
        DWORD Field04Pointer;
        DWORD Field04Plus60;
        DWORD Field43C8;
        BYTE Field264;
        BYTE Field265;
        BYTE Field43D8;
        BYTE Field154;
        BYTE Field156;
    };

    struct ProducerContextRecord
    {
        DWORD Sequence;
        ULONGLONG QpcTicks;
        DWORD CallerAddress;
        DWORD Helper;
        DWORD Side;
        DWORD ThreadId;
        DWORD TickCount;
        SYSTEMTIME LocalTime;
        DWORD CallerRva;
        DWORD ParentEbp;
        DWORD PlayerObject;
        DWORD Arg2;
        DWORD Arg3;
        DWORD Out4Pointer;
        DWORD Out5Pointer;
        DWORD Out4Before;
        DWORD Out4After;
        DWORD Out5Before;
        DWORD Out5After;
        LONG ResultEax;
        DWORD ParentLocalsReadableBefore;
        DWORD ParentLocalsReadableAfter;
        DWORD ParentLocalsBefore[kParentLocalCount];
        DWORD ParentLocalsAfter[kParentLocalCount];
        PlayerSnapshot PlayerBefore;
        PlayerSnapshot PlayerAfter;
    };

    struct HookState
    {
        const char* Name;
        DWORD Rva;
        const BYTE* Expected;
        DWORD PatchLength;
        void* Detour;
        BYTE* Target;
        BYTE* Trampoline;
        volatile LONG Installed;
    };

    constexpr BYTE kPrologueF34D0[] = { 0x55, 0x8B, 0xEC, 0x51, 0x53 };
    constexpr BYTE kPrologueF3930[] = { 0x55, 0x8B, 0xEC, 0x83, 0xEC, 0x18 };

    INIT_ONCE g_startOnce = INIT_ONCE_STATIC_INIT;
    HMODULE g_proxyModule = nullptr;
    HMODULE g_gameModule = nullptr;
    DWORD g_gameBase = 0;
    DWORD g_gameImageSize = 0;
    DWORD g_playerP1 = 0;
    DWORD g_playerP2 = 0;
    DWORD g_flushIntervalMs = kFlushIntervalDefaultMs;

    SRWLOCK g_recordLock = SRWLOCK_INIT;
    DWORD g_recordWriteIndex = 0;
    DWORD g_recordReadIndex = 0;
    DWORD g_recordCount = 0;
    volatile LONG g_droppedRecords = 0;
    volatile LONG g_hookCount = 0;
    volatile LONG g_helperCalls = 0;
    volatile LONG g_successRecords = 0;
    volatile LONG g_sampledFailureRecords = 0;
    volatile LONG g_unsampledFailures = 0;
    volatile LONG g_sequence = 0;
    constexpr DWORD kFailureCounterBuckets = 64u;
    volatile LONG g_failureCounters[2][2][kFailureCounterBuckets]{};
    DWORD g_failedSampleInterval = kFailedSampleIntervalDefault;
    ProducerContextRecord g_records[kRecordCapacity]{};

    Helper5Fn g_originalF34D0 = nullptr;
    Helper5Fn g_originalF3930 = nullptr;

    HookState g_hooks[] =
    {
        { "F34D0", kRvaF34D0, kPrologueF34D0, sizeof(kPrologueF34D0), nullptr, nullptr, nullptr, 0 },
        { "F3930", kRvaF3930, kPrologueF3930, sizeof(kPrologueF3930), nullptr, nullptr, nullptr, 0 }
    };

    bool GetSiblingPath(wchar_t* output, DWORD capacity, const wchar_t* filename)
    {
        if (output == nullptr || capacity == 0 || filename == nullptr || g_proxyModule == nullptr)
            return false;
        const DWORD length = GetModuleFileNameW(g_proxyModule, output, capacity);
        if (length == 0 || length >= capacity)
            return false;
        wchar_t* slash = wcsrchr(output, L'\\');
        wchar_t* forwardSlash = wcsrchr(output, L'/');
        if (forwardSlash != nullptr && (slash == nullptr || forwardSlash > slash))
            slash = forwardSlash;
        if (slash == nullptr)
            return false;
        *(slash + 1) = L'\0';
        const std::size_t used = wcslen(output);
        const std::size_t nameLength = wcslen(filename);
        if (used + nameLength + 1 > capacity)
            return false;
        wcscat_s(output, capacity, filename);
        return true;
    }

    void AppendLogAtTime(const SYSTEMTIME* timestamp, const char* message)
    {
        wchar_t path[MAX_PATH + 1]{};
        if (!GetSiblingPath(path, MAX_PATH, L"ArcanaAI_ProducerContextTrace.log"))
            return;
        SYSTEMTIME now{};
        if (timestamp != nullptr) now = *timestamp;
        else GetLocalTime(&now);
        char line[4200]{};
        const int count = sprintf_s(line, sizeof(line),
            "[%04u-%02u-%02u %02u:%02u:%02u.%03u] %s\r\n",
            now.wYear, now.wMonth, now.wDay, now.wHour, now.wMinute, now.wSecond,
            now.wMilliseconds, message != nullptr ? message : "(empty)");
        if (count <= 0) return;
        HANDLE file = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (file == INVALID_HANDLE_VALUE) return;
        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(count), &written, nullptr);
        CloseHandle(file);
    }

    void AppendLog(const char* message)
    {
        AppendLogAtTime(nullptr, message);
    }

    int ReadIniInt(const wchar_t* section, const wchar_t* key, int defaultValue)
    {
        wchar_t path[MAX_PATH + 1]{};
        if (!GetSiblingPath(path, MAX_PATH, L"ArcanaAI.ini"))
            return defaultValue;
        return GetPrivateProfileIntW(section, key, defaultValue, path);
    }

    bool GetImageFingerprint32(HMODULE module, DWORD* imageSize, DWORD* timestamp)
    {
        if (module == nullptr || imageSize == nullptr || timestamp == nullptr)
            return false;
        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(module);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0)
            return false;
        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(
            reinterpret_cast<const BYTE*>(module) + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC)
            return false;
        *imageSize = nt->OptionalHeader.SizeOfImage;
        *timestamp = nt->FileHeader.TimeDateStamp;
        return true;
    }

    bool SafeReadDword(DWORD address, DWORD* value)
    {
        if (address == 0 || value == nullptr) return false;
        __try
        {
            *value = *reinterpret_cast<const volatile DWORD*>(address);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *value = 0;
            return false;
        }
    }

    bool SafeReadWord(DWORD address, WORD* value)
    {
        if (address == 0 || value == nullptr) return false;
        __try
        {
            *value = *reinterpret_cast<const volatile WORD*>(address);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *value = 0;
            return false;
        }
    }

    bool SafeReadByte(DWORD address, BYTE* value)
    {
        if (address == 0 || value == nullptr) return false;
        __try
        {
            *value = *reinterpret_cast<const volatile BYTE*>(address);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *value = 0;
            return false;
        }
    }

    DWORD ReadOutputValue(DWORD* pointer)
    {
        DWORD value = 0xFFFFFFFFu;
        if (pointer != nullptr)
            SafeReadDword(static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(pointer)), &value);
        return value;
    }

    PlayerSnapshot ReadPlayerSnapshot(DWORD player)
    {
        PlayerSnapshot s{};
        SafeReadDword(player + kPlayerControlOffset, &s.CpuControl);
        SafeReadWord(player + 0x3A34u, &s.Field3A34);
        SafeReadWord(player + 0x3A36u, &s.Field3A36);
        SafeReadDword(player + 0x3F20u, &s.Field3F20);
        SafeReadDword(player + 0x3F30u, &s.Field3F30);
        SafeReadDword(player + 0x3F78u, &s.Field3F78);
        SafeReadDword(player + 0x3A70u, &s.Field3A70);
        SafeReadDword(player + 0x3A74u, &s.Field3A74);
        SafeReadDword(player + 0x3A78u, &s.Field3A78);
        SafeReadDword(player + 0x3B70u, &s.Field3B70);
        SafeReadDword(player + 0x3B74u, &s.Field3B74);
        SafeReadDword(player + 0x3B90u, &s.Field3B90);
        SafeReadDword(player + 0x3B78u, &s.Field3B78);
        SafeReadDword(player + 0x3B7Cu, &s.Field3B7C);
        SafeReadDword(player + 0x3B80u, &s.Field3B80);
        SafeReadDword(player + 0x3B84u, &s.Field3B84);
        SafeReadDword(player + 0x3B88u, &s.Field3B88);
        SafeReadDword(player + 0x3F50u, &s.Field3F50);
        SafeReadDword(player + 0x3F58u, &s.Field3F58);
        SafeReadDword(player + 0x04u, &s.Field04Pointer);
        if (s.Field04Pointer != 0)
            SafeReadDword(s.Field04Pointer + 0x60u, &s.Field04Plus60);
        SafeReadDword(player + 0x43C8u, &s.Field43C8);
        SafeReadByte(player + 0x264u, &s.Field264);
        SafeReadByte(player + 0x265u, &s.Field265);
        SafeReadByte(player + 0x43D8u, &s.Field43D8);
        SafeReadByte(player + 0x154u, &s.Field154);
        SafeReadByte(player + 0x156u, &s.Field156);
        return s;
    }

    bool ReadParentLocals(DWORD parentEbp, DWORD* values)
    {
        if (parentEbp == 0 || values == nullptr) return false;
        __try
        {
            const volatile DWORD* source = reinterpret_cast<const volatile DWORD*>(parentEbp - kParentLocalBytes);
            for (DWORD i = 0; i < kParentLocalCount; ++i)
                values[i] = source[i];
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            for (DWORD i = 0; i < kParentLocalCount; ++i)
                values[i] = 0;
            return false;
        }
    }

    bool GetSideForPlayer(DWORD player, DWORD* side)
    {
        if (player == g_playerP1)
        {
            if (side != nullptr) *side = 1;
            return true;
        }
        if (player == g_playerP2)
        {
            if (side != nullptr) *side = 2;
            return true;
        }
        return false;
    }

    DWORD GetCallerRva(DWORD callerAddress)
    {
        if (callerAddress < g_gameBase || callerAddress - g_gameBase >= g_gameImageSize) return 0xFFFFFFFFu;
        return callerAddress - g_gameBase;
    }
    DWORD GetHelperIndex(HelperId helper)
    {
        switch (helper)
        {
        case HelperId::F34D0: return 0;
        case HelperId::F3930: return 1;
        default: return 0;
        }
    }
    bool ShouldSampleFailedCall(HelperId helper, DWORD side, DWORD callerRva)
    {
        if(side<1||side>2)return false;
        const DWORD sideIndex=side-1;
        const DWORD helperIndex=GetHelperIndex(helper);
        const DWORD hashInput=callerRva==0xFFFFFFFFu?0u:(callerRva^(callerRva>>7)^(callerRva>>13));
        const DWORD bucket=hashInput&(kFailureCounterBuckets-1u);
        const LONG ordinal=InterlockedIncrement(&g_failureCounters[sideIndex][helperIndex][bucket]);
        const DWORD interval=g_failedSampleInterval==0?kFailedSampleIntervalDefault:g_failedSampleInterval;
        return ordinal==1||((static_cast<DWORD>(ordinal)-1u)%interval)==0;
    }

    bool RecordProducerContext(
        HelperId helper,DWORD side,DWORD callerRva,DWORD callerAddress,DWORD parentEbp,
        DWORD player,DWORD arg2,DWORD arg3,DWORD* out4,DWORD* out5,
        DWORD out4Before,DWORD out5Before,const PlayerSnapshot& playerBefore,
        const DWORD* parentLocalsBefore,bool parentLocalsReadableBefore,LONG resultEax)
    {
        ProducerContextRecord record{};
        record.Helper=static_cast<DWORD>(helper);record.Side=side;record.ThreadId=GetCurrentThreadId();
        record.TickCount=GetTickCount();GetLocalTime(&record.LocalTime);record.CallerRva=callerRva;record.CallerAddress=callerAddress;
        record.ParentEbp=parentEbp;record.PlayerObject=player;record.Arg2=arg2;record.Arg3=arg3;
        record.Out4Pointer=static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(out4));record.Out5Pointer=static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(out5));
        record.Out4Before=out4Before;record.Out4After=ReadOutputValue(out4);record.Out5Before=out5Before;record.Out5After=ReadOutputValue(out5);
        record.ResultEax=resultEax;record.ParentLocalsReadableBefore=parentLocalsReadableBefore?1u:0u;
        record.ParentLocalsReadableAfter=ReadParentLocals(parentEbp,record.ParentLocalsAfter)?1u:0u;
        for(DWORD i=0;i<kParentLocalCount;++i)record.ParentLocalsBefore[i]=parentLocalsBefore?parentLocalsBefore[i]:0;
        record.PlayerBefore=playerBefore;record.PlayerAfter=ReadPlayerSnapshot(player);
        AcquireSRWLockExclusive(&g_recordLock);
        if(g_recordCount>=kRecordCapacity){ReleaseSRWLockExclusive(&g_recordLock);InterlockedIncrement(&g_droppedRecords);return false;}
        LARGE_INTEGER qpc{};QueryPerformanceCounter(&qpc);record.Sequence=static_cast<DWORD>(InterlockedIncrement(&g_sequence));record.QpcTicks=static_cast<ULONGLONG>(qpc.QuadPart);
        g_records[g_recordWriteIndex]=record;g_recordWriteIndex=(g_recordWriteIndex+1u)%kRecordCapacity;++g_recordCount;
        ReleaseSRWLockExclusive(&g_recordLock);return true;
    }



    int CaptureAndCall(
        HelperId helper,void* playerPointer,DWORD arg2,DWORD arg3,DWORD* out4,DWORD* out5,DWORD callerAddress,DWORD parentEbp)
    {
        Helper5Fn original = helper == HelperId::F34D0 ? g_originalF34D0 : g_originalF3930;
        if(original==nullptr)return -1;
        DWORD side=0;const DWORD callerRva=GetCallerRva(callerAddress);
        const DWORD player=static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(playerPointer));
        const bool knownPlayer=playerPointer!=nullptr&&GetSideForPlayer(player,&side);
        DWORD cpuMode=0;const bool cpuPlayer=knownPlayer&&SafeReadDword(player+kPlayerControlOffset,&cpuMode)&&cpuMode==1;
        const bool capture=knownPlayer&&cpuPlayer;
        DWORD out4Before=0xFFFFFFFFu,out5Before=0xFFFFFFFFu,parentLocalsBefore[kParentLocalCount]{};
        bool parentLocalsReadableBefore=false;PlayerSnapshot playerBefore{};
        if(capture){InterlockedIncrement(&g_helperCalls);out4Before=ReadOutputValue(out4);out5Before=ReadOutputValue(out5);parentLocalsReadableBefore=ReadParentLocals(parentEbp,parentLocalsBefore);playerBefore=ReadPlayerSnapshot(player);}
        const int result=original(playerPointer,arg2,arg3,out4,out5);
        if(capture){
            const bool successful=static_cast<DWORD>(result)!=0xFFFFFFFFu;
            const bool sampleFailure=!successful&&ShouldSampleFailedCall(helper,side,callerRva);
            if(successful||sampleFailure){
                const bool queued=RecordProducerContext(helper,side,callerRva,callerAddress,parentEbp,player,arg2,arg3,out4,out5,out4Before,out5Before,playerBefore,parentLocalsBefore,parentLocalsReadableBefore,result);
                if(queued){if(successful)InterlockedIncrement(&g_successRecords);else InterlockedIncrement(&g_sampledFailureRecords);}
            }else InterlockedIncrement(&g_unsampledFailures);
        }
        return result;
    }



    const char* HelperName(DWORD helper)
    {
        switch (static_cast<HelperId>(helper))
        {
        case HelperId::F34D0: return "F34D0";
        case HelperId::F3930: return "F3930";
        default: return "UNKNOWN";
        }
    }

    bool MakeRelativeJump(BYTE* source, const void* destination, BYTE* output, DWORD patchLength)
    {
        if (source == nullptr || destination == nullptr || output == nullptr || patchLength < 5)
            return false;
        const std::intptr_t delta = reinterpret_cast<std::intptr_t>(destination) -
            (reinterpret_cast<std::intptr_t>(source) + 5);
        if (delta < INT32_MIN || delta > INT32_MAX)
            return false;
        output[0] = 0xE9;
        const std::int32_t relative = static_cast<std::int32_t>(delta);
        std::memcpy(output + 1, &relative, sizeof(relative));
        for (DWORD i = 5; i < patchLength; ++i)
            output[i] = 0x90;
        return true;
    }

    DWORD SuspendOtherProcessThreads(HANDLE* suspended, DWORD capacity)
    {
        if (suspended == nullptr || capacity == 0) return 0;
        const DWORD processId = GetCurrentProcessId();
        const DWORD currentThreadId = GetCurrentThreadId();
        DWORD count = 0;
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snapshot == INVALID_HANDLE_VALUE) return 0;
        THREADENTRY32 entry{};
        entry.dwSize = sizeof(entry);
        if (Thread32First(snapshot, &entry))
        {
            do
            {
                if (entry.th32OwnerProcessID == processId &&
                    entry.th32ThreadID != currentThreadId && count < capacity)
                {
                    HANDLE thread = OpenThread(THREAD_SUSPEND_RESUME, FALSE, entry.th32ThreadID);
                    if (thread != nullptr)
                    {
                        if (SuspendThread(thread) != static_cast<DWORD>(-1))
                            suspended[count++] = thread;
                        else
                            CloseHandle(thread);
                    }
                }
                entry.dwSize = sizeof(entry);
            } while (Thread32Next(snapshot, &entry));
        }
        CloseHandle(snapshot);
        return count;
    }

    void ResumeThreads(HANDLE* suspended, DWORD count)
    {
        if (suspended == nullptr) return;
        while (count > 0)
        {
            HANDLE thread = suspended[--count];
            ResumeThread(thread);
            CloseHandle(thread);
        }
    }

    bool InstallEntryHook(HookState& hook)
    {
        BYTE* target = reinterpret_cast<BYTE*>(static_cast<std::uintptr_t>(g_gameBase + hook.Rva));
        if (target == nullptr || hook.PatchLength < 5 || hook.PatchLength > 16)
        {
            AppendLog("ERROR: invalid producer-helper patch target or length.");
            return false;
        }
        if (std::memcmp(target, hook.Expected, hook.PatchLength) != 0)
        {
            char message[256]{};
            sprintf_s(message, "ERROR: %s prologue mismatch at RVA=0x%08lX; refusing to patch.",
                hook.Name, static_cast<unsigned long>(hook.Rva));
            AppendLog(message);
            return false;
        }

        BYTE* trampoline = static_cast<BYTE*>(VirtualAlloc(nullptr, hook.PatchLength + 5,
            MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
        if (trampoline == nullptr)
        {
            AppendLog("ERROR: VirtualAlloc failed for producer-helper trampoline.");
            return false;
        }
        std::memcpy(trampoline, target, hook.PatchLength);
        if (!MakeRelativeJump(trampoline + hook.PatchLength,
            target + hook.PatchLength, trampoline + hook.PatchLength, 5))
        {
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendLog("ERROR: could not construct producer-helper trampoline jump.");
            return false;
        }

        BYTE patch[16]{};
        if (!MakeRelativeJump(target, hook.Detour, patch, hook.PatchLength))
        {
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendLog("ERROR: producer-helper detour is outside rel32 jump range.");
            return false;
        }

        // Publish the callable original before the detour becomes visible.
        hook.Target = target;
        hook.Trampoline = trampoline;
        if (hook.Rva == kRvaF34D0)
            g_originalF34D0 = reinterpret_cast<Helper5Fn>(trampoline);
        else if (hook.Rva == kRvaF3930)
            g_originalF3930 = reinterpret_cast<Helper5Fn>(trampoline);
        FlushInstructionCache(GetCurrentProcess(), trampoline, hook.PatchLength + 5);

        HANDLE suspended[512]{};
        const DWORD suspendedCount = SuspendOtherProcessThreads(suspended,
            static_cast<DWORD>(sizeof(suspended) / sizeof(suspended[0])));

        DWORD oldProtect = 0;
        if (!VirtualProtect(target, hook.PatchLength, PAGE_EXECUTE_READWRITE, &oldProtect))
        {
            ResumeThreads(suspended, suspendedCount);
            VirtualFree(trampoline, 0, MEM_RELEASE);
            hook.Trampoline = nullptr;
            hook.Target = nullptr;
            if (hook.Rva == kRvaF34D0) g_originalF34D0 = nullptr;
            else if (hook.Rva == kRvaF3930) g_originalF3930 = nullptr;
            AppendLog("ERROR: VirtualProtect failed for producer-helper target.");
            return false;
        }

        // Recheck under suspension in case another component changed the bytes.
        if (std::memcmp(target, hook.Expected, hook.PatchLength) != 0)
        {
            DWORD ignored = 0;
            VirtualProtect(target, hook.PatchLength, oldProtect, &ignored);
            ResumeThreads(suspended, suspendedCount);
            VirtualFree(trampoline, 0, MEM_RELEASE);
            hook.Trampoline = nullptr;
            hook.Target = nullptr;
            if (hook.Rva == kRvaF34D0) g_originalF34D0 = nullptr;
            else if (hook.Rva == kRvaF3930) g_originalF3930 = nullptr;
            AppendLog("ERROR: producer-helper prologue changed during patch installation; patch cancelled.");
            return false;
        }

        std::memcpy(target, patch, hook.PatchLength);
        FlushInstructionCache(GetCurrentProcess(), target, hook.PatchLength);
        InterlockedExchange(&hook.Installed, 1);
        DWORD ignored = 0;
        VirtualProtect(target, hook.PatchLength, oldProtect, &ignored);
        ResumeThreads(suspended, suspendedCount);

        char message[256]{};
        sprintf_s(message, "Installed Stage 10 all-caller helper hook %s at RVA=0x%08lX (patch=%lu bytes; suspended=%lu thread(s)).",
            hook.Name, static_cast<unsigned long>(hook.Rva),
            static_cast<unsigned long>(hook.PatchLength), static_cast<unsigned long>(suspendedCount));
        AppendLog(message);
        return true;
    }

    void FlushReadyRecords()
    {
        for(;;){
            ProducerContextRecord record{};
            AcquireSRWLockExclusive(&g_recordLock);
            if(g_recordCount==0){ReleaseSRWLockExclusive(&g_recordLock);break;}
            record=g_records[g_recordReadIndex];g_recordReadIndex=(g_recordReadIndex+1u)%kRecordCapacity;--g_recordCount;
            ReleaseSRWLockExclusive(&g_recordLock);
            const ProducerContextRecord& r=record;
            char message[4000]{};
            int used = sprintf_s(message, sizeof(message),
                "PRODUCER_CONTEXT seq=%lu qpc=%I64u helper=%s side=P%lu tid=%lu tick=%lu caller=0x%08lX callerRVA=0x%08lX parentEBP=0x%08lX player=0x%08lX arg2=0x%08lX arg3=0x%08lX out4Ptr=0x%08lX out4=(0x%08lX->0x%08lX) out5Ptr=0x%08lX out5=(0x%08lX->0x%08lX) resultEAX=0x%08lX(%ld) parentLocalsReadable=(%lu,%lu) localsBefore=(",
                static_cast<unsigned long>(r.Sequence),
                static_cast<unsigned __int64>(r.QpcTicks),
                HelperName(r.Helper), static_cast<unsigned long>(r.Side),
                static_cast<unsigned long>(r.ThreadId), static_cast<unsigned long>(r.TickCount),
                static_cast<unsigned long>(r.CallerAddress),
                static_cast<unsigned long>(r.CallerRva), static_cast<unsigned long>(r.ParentEbp),
                static_cast<unsigned long>(r.PlayerObject), static_cast<unsigned long>(r.Arg2),
                static_cast<unsigned long>(r.Arg3), static_cast<unsigned long>(r.Out4Pointer),
                static_cast<unsigned long>(r.Out4Before), static_cast<unsigned long>(r.Out4After),
                static_cast<unsigned long>(r.Out5Pointer), static_cast<unsigned long>(r.Out5Before),
                static_cast<unsigned long>(r.Out5After), static_cast<unsigned long>(r.ResultEax),
                static_cast<long>(r.ResultEax),
                static_cast<unsigned long>(r.ParentLocalsReadableBefore),
                static_cast<unsigned long>(r.ParentLocalsReadableAfter));

            if (used > 0)
            {
                for (DWORD i = 0; i < kParentLocalCount; ++i)
                {
                    const DWORD offset = kParentLocalBytes - i * sizeof(DWORD);
                    const int n = sprintf_s(message + used, sizeof(message) - static_cast<std::size_t>(used),
                        "%sL-%03lX:%08lX", i == 0 ? "" : ",",
                        static_cast<unsigned long>(offset),
                        static_cast<unsigned long>(r.ParentLocalsBefore[i]));
                    if (n <= 0) break;
                    used += n;
                }
                const int n = sprintf_s(message + used, sizeof(message) - static_cast<std::size_t>(used), "),localsAfter=(");
                if (n > 0) used += n;
                for (DWORD i = 0; i < kParentLocalCount; ++i)
                {
                    const DWORD offset = kParentLocalBytes - i * sizeof(DWORD);
                    const int n2 = sprintf_s(message + used, sizeof(message) - static_cast<std::size_t>(used),
                        "%sL-%03lX:%08lX", i == 0 ? "" : ",",
                        static_cast<unsigned long>(offset),
                        static_cast<unsigned long>(r.ParentLocalsAfter[i]));
                    if (n2 <= 0) break;
                    used += n2;
                }
                const int n3 = sprintf_s(message + used, sizeof(message) - static_cast<std::size_t>(used),
                    "),playerBefore=(CPU:%08lX 3A34:%04lX 3A36:%04lX 3F20:%08lX 3F30:%08lX 3F78:%08lX 3A70:%08lX 3A74:%08lX 3A78:%08lX 3B70:%08lX 3B74:%08lX 3B78:%08lX 3B7C:%08lX 3B80:%08lX 3B84:%08lX 3B88:%08lX 3B90:%08lX 3F50:%08lX 3F58:%08lX +04:%08lX [+04+60]:%08lX 43C8:%08lX 264:%02lX 265:%02lX 43D8:%02lX 154:%02lX 156:%02lX),playerAfter=(CPU:%08lX 3A34:%04lX 3A36:%04lX 3F20:%08lX 3F30:%08lX 3F78:%08lX 3A70:%08lX 3A74:%08lX 3A78:%08lX 3B70:%08lX 3B74:%08lX 3B78:%08lX 3B7C:%08lX 3B80:%08lX 3B84:%08lX 3B88:%08lX 3B90:%08lX 3F50:%08lX 3F58:%08lX +04:%08lX [+04+60]:%08lX 43C8:%08lX 264:%02lX 265:%02lX 43D8:%02lX 154:%02lX 156:%02lX)",
                    static_cast<unsigned long>(r.PlayerBefore.CpuControl),
                    static_cast<unsigned long>(r.PlayerBefore.Field3A34),
                    static_cast<unsigned long>(r.PlayerBefore.Field3A36),
                    static_cast<unsigned long>(r.PlayerBefore.Field3F20),
                    static_cast<unsigned long>(r.PlayerBefore.Field3F30),
                    static_cast<unsigned long>(r.PlayerBefore.Field3F78),
                    static_cast<unsigned long>(r.PlayerBefore.Field3A70),
                    static_cast<unsigned long>(r.PlayerBefore.Field3A74),
                    static_cast<unsigned long>(r.PlayerBefore.Field3A78),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B70),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B74),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B78),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B7C),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B80),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B84),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B88),
                    static_cast<unsigned long>(r.PlayerBefore.Field3B90),
                    static_cast<unsigned long>(r.PlayerBefore.Field3F50),
                    static_cast<unsigned long>(r.PlayerBefore.Field3F58),
                    static_cast<unsigned long>(r.PlayerBefore.Field04Pointer),
                    static_cast<unsigned long>(r.PlayerBefore.Field04Plus60),
                    static_cast<unsigned long>(r.PlayerBefore.Field43C8),
                    static_cast<unsigned long>(r.PlayerBefore.Field264),
                    static_cast<unsigned long>(r.PlayerBefore.Field265),
                    static_cast<unsigned long>(r.PlayerBefore.Field43D8),
                    static_cast<unsigned long>(r.PlayerBefore.Field154),
                    static_cast<unsigned long>(r.PlayerBefore.Field156),
                    static_cast<unsigned long>(r.PlayerAfter.CpuControl),
                    static_cast<unsigned long>(r.PlayerAfter.Field3A34),
                    static_cast<unsigned long>(r.PlayerAfter.Field3A36),
                    static_cast<unsigned long>(r.PlayerAfter.Field3F20),
                    static_cast<unsigned long>(r.PlayerAfter.Field3F30),
                    static_cast<unsigned long>(r.PlayerAfter.Field3F78),
                    static_cast<unsigned long>(r.PlayerAfter.Field3A70),
                    static_cast<unsigned long>(r.PlayerAfter.Field3A74),
                    static_cast<unsigned long>(r.PlayerAfter.Field3A78),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B70),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B74),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B78),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B7C),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B80),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B84),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B88),
                    static_cast<unsigned long>(r.PlayerAfter.Field3B90),
                    static_cast<unsigned long>(r.PlayerAfter.Field3F50),
                    static_cast<unsigned long>(r.PlayerAfter.Field3F58),
                    static_cast<unsigned long>(r.PlayerAfter.Field04Pointer),
                    static_cast<unsigned long>(r.PlayerAfter.Field04Plus60),
                    static_cast<unsigned long>(r.PlayerAfter.Field43C8),
                    static_cast<unsigned long>(r.PlayerAfter.Field264),
                    static_cast<unsigned long>(r.PlayerAfter.Field265),
                    static_cast<unsigned long>(r.PlayerAfter.Field43D8),
                    static_cast<unsigned long>(r.PlayerAfter.Field154),
                    static_cast<unsigned long>(r.PlayerAfter.Field156));
                if (n3 > 0) used += n3;
            }

            AppendLogAtTime(&r.LocalTime, message);
        }
    }

    DWORD WINAPI ProducerContextTraceWorker(void*)
    {
        const int enabled = ReadIniInt(L"AIResearch", L"EnableAIProducerContextTrace", 1);
        int flushMs = ReadIniInt(L"AIResearch", L"ProducerContextTraceFlushIntervalMs",
            static_cast<int>(kFlushIntervalDefaultMs));
        int sampleInterval = ReadIniInt(L"AIResearch", L"ProducerContextFailedResultSampleInterval",
            static_cast<int>(kFailedSampleIntervalDefault));
        if (sampleInterval < 1) sampleInterval = 1;
        if (sampleInterval > 256) sampleInterval = 256;
        g_failedSampleInterval = static_cast<DWORD>(sampleInterval);
        if (flushMs < static_cast<int>(kFlushIntervalMinMs)) flushMs = kFlushIntervalMinMs;
        if (flushMs > static_cast<int>(kFlushIntervalMaxMs)) flushMs = kFlushIntervalMaxMs;
        g_flushIntervalMs = static_cast<DWORD>(flushMs);

        if (enabled == 0)
        {
            AppendLog("Stage 10 producer-context trace is disabled in ArcanaAI.ini. No helper hooks were installed.");
            return 0;
        }

        for (int attempt = 0; attempt < 300; ++attempt)
        {
            g_gameModule = GetModuleHandleW(L"AALib.exe");
            if (g_gameModule != nullptr) break;
            Sleep(100);
        }
        if (g_gameModule == nullptr)
        {
            AppendLog("ERROR: AALib.exe was not found; Stage 10 producer-context trace stopped.");
            return 0;
        }

        g_gameBase = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(g_gameModule));
        DWORD timestamp = 0;
        if (!GetImageFingerprint32(g_gameModule, &g_gameImageSize, &timestamp) ||
            g_gameImageSize != kExpectedImageSize || timestamp != kExpectedTimeDateStamp)
        {
            AppendLog("ERROR: AALib.exe fingerprint mismatch; no Stage 8 producer-context hooks were installed.");
            return 0;
        }
        g_playerP1 = g_gameBase + kP1ControlRva - kPlayerControlOffset;
        g_playerP2 = g_gameBase + kP2ControlRva - kPlayerControlOffset;

        g_hooks[0].Detour = reinterpret_cast<void*>(&ArcanaStage10HookF34D0);
        g_hooks[1].Detour = reinterpret_cast<void*>(&ArcanaStage10HookF3930);

        char start[420]{};
        sprintf_s(start,
            "Stage 10 producer-context trace requested. gameBase=0x%08lX P1=0x%08lX P2=0x%08lX; callerFilter=none; successfulResults=all; failedResultsSampled=1/%lu per side/helper/caller bucket; ringCapacity=%lu frameBytes=0x%lX flush=%lu ms.",
            static_cast<unsigned long>(g_gameBase), static_cast<unsigned long>(g_playerP1),
            static_cast<unsigned long>(g_playerP2), static_cast<unsigned long>(g_failedSampleInterval),
            static_cast<unsigned long>(kRecordCapacity), static_cast<unsigned long>(kParentLocalBytes),
            static_cast<unsigned long>(g_flushIntervalMs));
        AppendLog(start);

        HANDLE patchMutex = CreateMutexW(nullptr, FALSE, L"Local\\ArcanaAIOverhaul_PatchInstall_Mutex");
        if (patchMutex == nullptr)
        {
            AppendLog("ERROR: could not create shared patch-install mutex; Stage 8 hooks were not installed.");
            return 0;
        }
        const DWORD mutexWait = WaitForSingleObject(patchMutex, INFINITE);
        if (mutexWait != WAIT_OBJECT_0 && mutexWait != WAIT_ABANDONED)
        {
            AppendLog("ERROR: could not acquire shared patch-install mutex; Stage 8 hooks were not installed.");
            CloseHandle(patchMutex);
            return 0;
        }

        for (HookState& hook : g_hooks)
            InstallEntryHook(hook);

        ReleaseMutex(patchMutex);
        CloseHandle(patchMutex);

        for (HookState& hook : g_hooks)
        {
            if (InterlockedCompareExchange(&hook.Installed, 0, 0) != 0)
                InterlockedIncrement(&g_hookCount);
        }

        char summary[160]{};
        sprintf_s(summary, "Stage 10 producer-context trace active. Installed helper hooks=%ld/2.",
            static_cast<long>(InterlockedCompareExchange(&g_hookCount, 0, 0)));
        AppendLog(summary);
        if (InterlockedCompareExchange(&g_hookCount, 0, 0) == 0)
        {
            AppendLog("ERROR: no Stage 8 helper hook was installed; trace worker stopped.");
            return 0;
        }

        for (;;)
        {
            Sleep(g_flushIntervalMs);
            FlushReadyRecords();
            const LONG dropped = InterlockedCompareExchange(&g_droppedRecords, 0, 0);
            if (dropped != 0)
            {
                char warning[160]{};
                sprintf_s(warning, "WARNING: Stage 8 producer-context record buffer full; dropped records=%ld.",
                    static_cast<long>(dropped));
                AppendLog(warning);
                InterlockedExchange(&g_droppedRecords, 0);
            }
        }
    }

    BOOL CALLBACK StartProducerContextTraceWorker(PINIT_ONCE, PVOID, PVOID*)
    {
        HANDLE thread = CreateThread(nullptr, 0, ProducerContextTraceWorker, nullptr, 0, nullptr);
        if (thread == nullptr)
            AppendLog("ERROR: failed to create Stage 10 producer-context trace worker thread.");
        else
            CloseHandle(thread);
        return TRUE;
    }
}

extern "C" int __cdecl ArcanaStage10CaptureF34D0(
    void* player, DWORD arg2, DWORD arg3, DWORD* out4, DWORD* out5,
    DWORD callerAddress, DWORD parentEbp)
{
    return CaptureAndCall(HelperId::F34D0, player, arg2, arg3, out4, out5, callerAddress, parentEbp);
}

extern "C" int __cdecl ArcanaStage10CaptureF3930(
    void* player, DWORD arg2, DWORD arg3, DWORD* out4, DWORD* out5,
    DWORD callerAddress, DWORD parentEbp)
{
    return CaptureAndCall(HelperId::F3930, player, arg2, arg3, out4, out5, callerAddress, parentEbp);
}

extern "C" __declspec(naked) int ArcanaStage10HookF34D0()
{
    __asm
    {
        pushfd
        pushad
        mov edx, esp

        // Worker args (right-to-left): player, arg2, arg3, out4, out5,
        // original return address, caller EBP.
        push dword ptr [edx + 8]
        push dword ptr [edx + 36]
        push dword ptr [edx + 56]
        push dword ptr [edx + 52]
        push dword ptr [edx + 48]
        push dword ptr [edx + 44]
        push dword ptr [edx + 40]
        call ArcanaStage10CaptureF34D0
        add esp, 28

        // Preserve the original callee-save registers/flags but return the
        // original helper's EAX result from the saved EAX slot.
        mov dword ptr [esp + 28], eax
        popad
        popfd
        ret
    }
}

extern "C" __declspec(naked) int ArcanaStage10HookF3930()
{
    __asm
    {
        pushfd
        pushad
        mov edx, esp

        push dword ptr [edx + 8]
        push dword ptr [edx + 36]
        push dword ptr [edx + 56]
        push dword ptr [edx + 52]
        push dword ptr [edx + 48]
        push dword ptr [edx + 44]
        push dword ptr [edx + 40]
        call ArcanaStage10CaptureF3930
        add esp, 28

        mov dword ptr [esp + 28], eax
        popad
        popfd
        ret
    }
}

void StartAIProducerContextTrace(HMODULE proxyModule)
{
    g_proxyModule = proxyModule;
    InitOnceExecuteOnce(&g_startOnce, StartProducerContextTraceWorker, nullptr, nullptr);
}
