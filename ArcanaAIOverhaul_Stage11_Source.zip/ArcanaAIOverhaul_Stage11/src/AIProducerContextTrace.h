#pragma once

#include <Windows.h>

void StartAIProducerContextTrace(HMODULE proxyModule);
