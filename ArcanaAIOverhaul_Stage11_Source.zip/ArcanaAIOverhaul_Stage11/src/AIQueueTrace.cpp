#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <TlHelp32.h>
#include <intrin.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <cwchar>

#include "AIQueueTrace.h"

namespace
{
    constexpr DWORD kExpectedImageSize = 0x0E0EB000u;
    constexpr DWORD kExpectedTimeDateStamp = 0x5FE5AA91u;

    constexpr DWORD kP1ControlRva = 0x0DCA5EA4u;
    constexpr DWORD kP2ControlRva = 0x0DCD0BCCu;
    constexpr DWORD kPlayerControlOffset = 0x3F2Cu;
    constexpr DWORD kPlayerSideOffset = 0x3F30u;
    constexpr DWORD kPlayerQueueOffset = 0x3A2Cu;

    // AALib.exe VA 0x004F2DE0, with preferred image base 0x00400000.
    constexpr DWORD kQueueInsertRva = 0x000F2DE0u;
    constexpr BYTE kExpectedPrologue[6] = { 0x55, 0x8B, 0xEC, 0x8B, 0x45, 0x08 };

    // AALib.exe VA 0x004EE200 (RVA 0x000EE200): dispatches a resolved
    // per-player event by event type and payload. The entry prologue is 7 bytes.
    constexpr DWORD kEventDispatchRva = 0x000EE200u;
    constexpr BYTE kEventDispatchPrologue[7] = { 0x55, 0x8B, 0xEC, 0x53, 0x8B, 0x5D, 0x0C };

    constexpr DWORD kSiteCapacity = 512;
    constexpr DWORD kDetailCapacity = 1024;
    constexpr DWORD kDetailStackDepth = 8;
    constexpr DWORD kDefaultFlushIntervalMs = 1000;
    constexpr DWORD kMinFlushIntervalMs = 250;
    constexpr DWORD kMaxFlushIntervalMs = 5000;

    using QueueInsertFn = void(__cdecl*)(void* queue, DWORD eventType, DWORD payload);
    using EventDispatchFn = void(__thiscall*)(void* player, DWORD eventType, DWORD payload);

    struct QueueSnapshot
    {
        BYTE active;
        BYTE field1;
        WORD storedType;
        WORD storedPayload;
        BYTE field6;
        BYTE field7;
        WORD field8;
        WORD field10;
        WORD field12;
        BYTE field14;
        BYTE guard;
    };

    struct QueueSite
    {
        // State: 0 = empty, -1 = being initialized, 1 = ready.
        volatile LONG State;
        volatile LONG Count;
        volatile LONG ReportedCount;
        DWORD Side;
        DWORD FirstThreadId;
        DWORD CallerRva;
        DWORD EventTypeArg;
        DWORD PayloadArg;
        DWORD GuardBefore;
        DWORD ActiveBefore;
        DWORD ActiveAfter;
        DWORD StoredTypeAfter;
        DWORD StoredPayloadAfter;
        DWORD GuardAfter;
    };

    struct EventDispatchSite
    {
        // State: 0 = empty, -1 = being initialized, 1 = ready.
        volatile LONG State;
        volatile LONG Count;
        volatile LONG ReportedCount;
        DWORD Side;
        DWORD FirstThreadId;
        DWORD CallerRva;
        DWORD EventTypeArg;
        DWORD PayloadArg;
        DWORD PlayerMode;
        DWORD QueueActiveBefore;
        DWORD QueueCurrentTypeBefore;
        DWORD QueueCurrentPayloadBefore;
        DWORD QueueHistoryTypeBefore;
        DWORD QueueHistoryPayloadBefore;
        DWORD QueueHistoryMatchesArgs;
        DWORD QueueGuardBefore;
        DWORD QueueActiveAfter;
        DWORD QueueHistoryTypeAfter;
        DWORD QueueHistoryPayloadAfter;
    };

    struct QueueEventDetailRecord
    {
        DWORD Sequence;
        DWORD Side;
        DWORD ThreadId;
        DWORD TickCount;
        ULONGLONG QpcTicks;
        DWORD CallerAddress;
        DWORD CallerRva;
        DWORD PlayerObject;
        DWORD QueueAddress;
        DWORD EventType;
        DWORD Payload;
        DWORD GuardBefore;
        DWORD ActiveBefore;
        DWORD AfterReadable;
        DWORD GuardAfter;
        DWORD ActiveAfter;
        DWORD StoredTypeAfter;
        DWORD StoredPayloadAfter;
        DWORD StackDepth;
        PVOID Stack[kDetailStackDepth];
    };

    INIT_ONCE g_startOnce = INIT_ONCE_STATIC_INIT;
    HMODULE g_proxyModule = nullptr;
    HMODULE g_gameModule = nullptr;
    DWORD g_gameBase = 0;
    DWORD g_gameImageSize = 0;
    DWORD g_playerP1 = 0;
    DWORD g_playerP2 = 0;
    DWORD g_p1Queue = 0;
    DWORD g_p2Queue = 0;
    DWORD g_flushIntervalMs = kDefaultFlushIntervalMs;

    BYTE* g_hookTarget = nullptr;
    BYTE* g_trampoline = nullptr;
    QueueInsertFn g_originalQueueInsert = nullptr;
    volatile LONG g_hookInstalled = 0;
    volatile LONG g_droppedSites = 0;
    volatile LONG g_loggedSites = 0;
    QueueSite g_sites[kSiteCapacity]{};

    BYTE* g_dispatchHookTarget = nullptr;
    BYTE* g_dispatchTrampoline = nullptr;
    EventDispatchFn g_originalEventDispatch = nullptr;
    volatile LONG g_dispatchHookInstalled = 0;
    volatile LONG g_dispatchDroppedSites = 0;
    volatile LONG g_dispatchLoggedSites = 0;
    EventDispatchSite g_dispatchSites[kSiteCapacity]{};

    SRWLOCK g_detailLock = SRWLOCK_INIT;
    QueueEventDetailRecord g_detailRecords[kDetailCapacity]{};
    DWORD g_detailReadIndex = 0;
    DWORD g_detailWriteIndex = 0;
    DWORD g_detailCount = 0;
    DWORD g_detailSequence = 0;
    volatile LONG g_detailDroppedRecords = 0;
    volatile LONG g_detailTraceEnabled = 0;

    bool GetSiblingPath(wchar_t* output, DWORD capacity, const wchar_t* filename)
    {
        if (output == nullptr || capacity == 0 || filename == nullptr || g_proxyModule == nullptr)
        {
            return false;
        }

        const DWORD length = GetModuleFileNameW(g_proxyModule, output, capacity);
        if (length == 0 || length >= capacity)
        {
            return false;
        }

        wchar_t* slash = wcsrchr(output, L'\\');
        wchar_t* forwardSlash = wcsrchr(output, L'/');
        if (forwardSlash != nullptr && (slash == nullptr || forwardSlash > slash))
        {
            slash = forwardSlash;
        }
        if (slash == nullptr)
        {
            return false;
        }

        *(slash + 1) = L'\0';
        const std::size_t used = wcslen(output);
        const std::size_t nameLength = wcslen(filename);
        if (used + nameLength + 1 > capacity)
        {
            return false;
        }
        wcscat_s(output, capacity, filename);
        return true;
    }

    void AppendQueueLog(const char* message)
    {
        wchar_t logPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(logPath, MAX_PATH, L"ArcanaAI_QueueTrace.log"))
        {
            return;
        }

        SYSTEMTIME now{};
        GetLocalTime(&now);
        char line[1024]{};
        const int count = sprintf_s(
            line,
            "[%04u-%02u-%02u %02u:%02u:%02u] %s\r\n",
            now.wYear, now.wMonth, now.wDay,
            now.wHour, now.wMinute, now.wSecond,
            message != nullptr ? message : "(empty)");
        if (count <= 0)
        {
            return;
        }

        HANDLE file = CreateFileW(
            logPath,
            FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            nullptr);
        if (file == INVALID_HANDLE_VALUE)
        {
            return;
        }

        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(count), &written, nullptr);
        CloseHandle(file);
    }

    void AppendDispatchLog(const char* message)
    {
        wchar_t logPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(logPath, MAX_PATH, L"ArcanaAI_EventDispatchTrace.log"))
        {
            return;
        }

        SYSTEMTIME now{};
        GetLocalTime(&now);
        char line[1200]{};
        const int count = sprintf_s(
            line,
            "[%04u-%02u-%02u %02u:%02u:%02u] %s\r\n",
            now.wYear, now.wMonth, now.wDay,
            now.wHour, now.wMinute, now.wSecond,
            message != nullptr ? message : "(empty)");
        if (count <= 0)
        {
            return;
        }

        HANDLE file = CreateFileW(
            logPath,
            FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            nullptr);
        if (file == INVALID_HANDLE_VALUE)
        {
            return;
        }

        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(count), &written, nullptr);
        CloseHandle(file);
    }

    int ReadIniInt(const wchar_t* section, const wchar_t* key, int defaultValue)
    {
        wchar_t iniPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(iniPath, MAX_PATH, L"ArcanaAI.ini"))
        {
            return defaultValue;
        }
        return GetPrivateProfileIntW(section, key, defaultValue, iniPath);
    }

    bool GetImageFingerprint32(HMODULE module, DWORD* imageSize, DWORD* timeDateStamp)
    {
        if (module == nullptr || imageSize == nullptr || timeDateStamp == nullptr)
        {
            return false;
        }

        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(module);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0)
        {
            return false;
        }

        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(
            reinterpret_cast<const BYTE*>(module) + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC)
        {
            return false;
        }

        *imageSize = nt->OptionalHeader.SizeOfImage;
        *timeDateStamp = nt->FileHeader.TimeDateStamp;
        return true;
    }

    bool SafeReadDword(DWORD address, DWORD* value)
    {
        if (address == 0 || value == nullptr)
        {
            return false;
        }
        __try
        {
            *value = *reinterpret_cast<const volatile DWORD*>(address);
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *value = 0;
            return false;
        }
    }

    bool SafeReadQueueSnapshot(DWORD address, QueueSnapshot* snapshot)
    {
        if (address == 0 || snapshot == nullptr)
        {
            return false;
        }
        __try
        {
            const volatile BYTE* p = reinterpret_cast<const volatile BYTE*>(address);
            snapshot->active = p[0];
            snapshot->field1 = p[1];
            snapshot->storedType = *reinterpret_cast<const volatile WORD*>(address + 2);
            snapshot->storedPayload = *reinterpret_cast<const volatile WORD*>(address + 4);
            snapshot->field6 = p[6];
            snapshot->field7 = p[7];
            snapshot->field8 = *reinterpret_cast<const volatile WORD*>(address + 8);
            snapshot->field10 = *reinterpret_cast<const volatile WORD*>(address + 10);
            snapshot->field12 = *reinterpret_cast<const volatile WORD*>(address + 12);
            snapshot->field14 = p[14];
            snapshot->guard = p[15];
            return true;
        }
        __except (EXCEPTION_EXECUTE_HANDLER)
        {
            *snapshot = {};
            return false;
        }
    }

    bool IsKnownPlayerQueue(DWORD queueAddress, DWORD* side, DWORD* playerObject)
    {
        if (queueAddress == g_p1Queue)
        {
            if (side != nullptr) *side = 1;
            if (playerObject != nullptr) *playerObject = g_playerP1;
            return true;
        }
        if (queueAddress == g_p2Queue)
        {
            if (side != nullptr) *side = 2;
            if (playerObject != nullptr) *playerObject = g_playerP2;
            return true;
        }
        return false;
    }

    bool SameSiteKey(const QueueSite& site, DWORD side, DWORD callerRva,
        DWORD eventType, DWORD payload, DWORD guardBefore)
    {
        return site.Side == side && site.CallerRva == callerRva &&
            site.EventTypeArg == eventType && site.PayloadArg == payload &&
            site.GuardBefore == guardBefore;
    }

    void AddQueueSite(DWORD side, DWORD threadId, DWORD callerRva,
        DWORD eventType, DWORD payload, const QueueSnapshot& before,
        const QueueSnapshot& after)
    {
        DWORD hash = callerRva ^ (eventType * 0x9E3779B9u) ^
            (payload * 0x85EBCA6Bu) ^ (side << 24) ^ (static_cast<DWORD>(before.guard) << 16);
        const DWORD start = hash % kSiteCapacity;

        for (DWORD probe = 0; probe < kSiteCapacity; ++probe)
        {
            QueueSite& site = g_sites[(start + probe) % kSiteCapacity];
            const LONG state = InterlockedCompareExchange(&site.State, 0, 0);
            if (state == 1 && SameSiteKey(site, side, callerRva, eventType, payload, before.guard))
            {
                InterlockedIncrement(&site.Count);
                return;
            }

            if (state == 0 && InterlockedCompareExchange(&site.State, -1, 0) == 0)
            {
                site.Side = side;
                site.FirstThreadId = threadId;
                site.CallerRva = callerRva;
                site.EventTypeArg = eventType;
                site.PayloadArg = payload;
                site.GuardBefore = before.guard;
                site.ActiveBefore = before.active;
                site.ActiveAfter = after.active;
                site.StoredTypeAfter = after.storedType;
                site.StoredPayloadAfter = after.storedPayload;
                site.GuardAfter = after.guard;
                InterlockedExchange(&site.Count, 1);
                MemoryBarrier();
                InterlockedExchange(&site.State, 1);
                InterlockedIncrement(&g_loggedSites);
                return;
            }
        }
        InterlockedIncrement(&g_droppedSites);
    }

    void AddQueueEventDetail(const QueueEventDetailRecord& source)
    {
        AcquireSRWLockExclusive(&g_detailLock);
        if (g_detailCount >= kDetailCapacity)
        {
            ReleaseSRWLockExclusive(&g_detailLock);
            InterlockedIncrement(&g_detailDroppedRecords);
            return;
        }
        QueueEventDetailRecord& slot = g_detailRecords[g_detailWriteIndex];
        slot = source;
        slot.Sequence = ++g_detailSequence;
        g_detailWriteIndex = (g_detailWriteIndex + 1u) % kDetailCapacity;
        ++g_detailCount;
        ReleaseSRWLockExclusive(&g_detailLock);
    }

    __declspec(noinline) void __cdecl QueueInsertHook(void* queue, DWORD eventType, DWORD payload)
    {
        const DWORD callerAddress = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(_ReturnAddress()));
        const DWORD callerRva = callerAddress >= g_gameBase ? callerAddress - g_gameBase : 0;
        const DWORD queueAddress = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(queue));
        DWORD side = 0;
        DWORD playerObject = 0;
        bool traceThisCall = false;
        QueueSnapshot before{};

        if (InterlockedCompareExchange(&g_hookInstalled, 0, 0) != 0 &&
            IsKnownPlayerQueue(queueAddress, &side, &playerObject))
        {
            DWORD cpuMode = 0;
            if (SafeReadDword(playerObject + kPlayerControlOffset, &cpuMode) && cpuMode == 1 &&
                SafeReadQueueSnapshot(queueAddress, &before))
                traceThisCall = true;
        }

        const bool captureDetail = traceThisCall && eventType == 1 &&
            InterlockedCompareExchange(&g_detailTraceEnabled, 0, 0) != 0;
        QueueEventDetailRecord detail{};
        if (captureDetail)
        {
            detail.Side = side;
            detail.ThreadId = GetCurrentThreadId();
            detail.TickCount = GetTickCount();
            LARGE_INTEGER qpc{};
            QueryPerformanceCounter(&qpc);
            detail.QpcTicks = static_cast<ULONGLONG>(qpc.QuadPart);
            detail.CallerAddress = callerAddress;
            detail.CallerRva = callerRva;
            detail.PlayerObject = playerObject;
            detail.QueueAddress = queueAddress;
            detail.EventType = eventType;
            detail.Payload = payload;
            detail.GuardBefore = before.guard;
            detail.ActiveBefore = before.active;
            detail.StackDepth = CaptureStackBackTrace(0, kDetailStackDepth, detail.Stack, nullptr);
        }

        QueueInsertFn original = g_originalQueueInsert;
        if (original != nullptr) original(queue, eventType, payload);

        if (traceThisCall)
        {
            QueueSnapshot after{};
            const bool afterReadable = SafeReadQueueSnapshot(queueAddress, &after);
            if (afterReadable)
                AddQueueSite(side, GetCurrentThreadId(), callerRva, eventType, payload, before, after);
            if (captureDetail)
            {
                detail.AfterReadable = afterReadable ? 1u : 0u;
                if (afterReadable)
                {
                    detail.GuardAfter = after.guard;
                    detail.ActiveAfter = after.active;
                    detail.StoredTypeAfter = after.storedType;
                    detail.StoredPayloadAfter = after.storedPayload;
                }
                AddQueueEventDetail(detail);
            }
        }
    }

    bool SameDispatchKey(const EventDispatchSite& site, DWORD side, DWORD callerRva,
        DWORD eventType, DWORD payload)
    {
        return site.Side == side && site.CallerRva == callerRva &&
            site.EventTypeArg == eventType && site.PayloadArg == payload;
    }

    void AddDispatchSite(DWORD side, DWORD threadId, DWORD callerRva,
        DWORD eventType, DWORD payload, DWORD playerMode,
        const QueueSnapshot& before, const QueueSnapshot& after)
    {
        const DWORD start = (callerRva ^ (eventType * 0x9E3779B9u) ^
            (payload * 0x85EBCA6Bu) ^ (side << 24)) % kSiteCapacity;

        for (DWORD probe = 0; probe < kSiteCapacity; ++probe)
        {
            EventDispatchSite& site = g_dispatchSites[(start + probe) % kSiteCapacity];
            const LONG state = InterlockedCompareExchange(&site.State, 0, 0);
            if (state == 1 && SameDispatchKey(site, side, callerRva, eventType, payload))
            {
                InterlockedIncrement(&site.Count);
                return;
            }

            if (state == 0 && InterlockedCompareExchange(&site.State, -1, 0) == 0)
            {
                site.Side = side;
                site.FirstThreadId = threadId;
                site.CallerRva = callerRva;
                site.EventTypeArg = eventType;
                site.PayloadArg = payload;
                site.PlayerMode = playerMode;
                site.QueueActiveBefore = before.active;
                site.QueueCurrentTypeBefore = before.storedType;
                site.QueueCurrentPayloadBefore = before.storedPayload;
                site.QueueHistoryTypeBefore = before.field8;
                site.QueueHistoryPayloadBefore = before.field10;
                site.QueueHistoryMatchesArgs =
                    (before.field8 == static_cast<WORD>(eventType) &&
                     before.field10 == static_cast<WORD>(payload)) ? 1u : 0u;
                site.QueueGuardBefore = before.guard;
                site.QueueActiveAfter = after.active;
                site.QueueHistoryTypeAfter = after.field8;
                site.QueueHistoryPayloadAfter = after.field10;
                InterlockedExchange(&site.Count, 1);
                MemoryBarrier();
                InterlockedExchange(&site.State, 1);
                InterlockedIncrement(&g_dispatchLoggedSites);
                return;
            }
        }
        InterlockedIncrement(&g_dispatchDroppedSites);
    }

    // The game calls this as __thiscall (ECX=player, two stack arguments).
    // A __fastcall detour preserves ECX, consumes the unused EDX slot, and
    // receives the same two stack arguments. The original is called exactly once.
    __declspec(noinline) void __fastcall EventDispatchHook(
        void* player, void*, DWORD eventType, DWORD payload)
    {
        const DWORD callerAddress = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(_ReturnAddress()));
        const DWORD playerAddress = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(player));
        DWORD side = 0;
        DWORD playerObject = 0;
        bool traceThisCall = false;
        DWORD playerMode = 0;
        QueueSnapshot before{};

        if (InterlockedCompareExchange(&g_dispatchHookInstalled, 0, 0) != 0 &&
            IsKnownPlayerQueue(playerAddress + kPlayerQueueOffset, &side, &playerObject) &&
            playerObject == playerAddress)
        {
            if (SafeReadDword(playerAddress + kPlayerControlOffset, &playerMode) && playerMode == 1 &&
                SafeReadQueueSnapshot(playerAddress + kPlayerQueueOffset, &before))
            {
                traceThisCall = true;
            }
        }

        EventDispatchFn original = g_originalEventDispatch;
        if (original != nullptr)
        {
            original(player, eventType, payload);
        }

        if (traceThisCall)
        {
            QueueSnapshot after{};
            if (SafeReadQueueSnapshot(playerAddress + kPlayerQueueOffset, &after))
            {
                const DWORD callerRva = callerAddress >= g_gameBase ? callerAddress - g_gameBase : 0;
                AddDispatchSite(side, GetCurrentThreadId(), callerRva,
                    eventType, payload, playerMode, before, after);
            }
        }
    }

    bool MakeRelativeJump(BYTE* source, const void* destination, BYTE* output)
    {
        if (source == nullptr || destination == nullptr || output == nullptr)
        {
            return false;
        }
        const std::intptr_t delta =
            reinterpret_cast<std::intptr_t>(destination) -
            (reinterpret_cast<std::intptr_t>(source) + 5);
        if (delta < INT32_MIN || delta > INT32_MAX)
        {
            return false;
        }
        output[0] = 0xE9;
        const std::int32_t relative = static_cast<std::int32_t>(delta);
        std::memcpy(output + 1, &relative, sizeof(relative));
        return true;
    }

    DWORD SuspendOtherProcessThreads(HANDLE* suspended, DWORD capacity)
    {
        if (suspended == nullptr || capacity == 0)
        {
            return 0;
        }

        const DWORD processId = GetCurrentProcessId();
        const DWORD currentThreadId = GetCurrentThreadId();
        DWORD count = 0;
        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
        {
            return 0;
        }

        THREADENTRY32 entry{};
        entry.dwSize = sizeof(entry);
        if (Thread32First(snapshot, &entry))
        {
            do
            {
                if (entry.th32OwnerProcessID == processId &&
                    entry.th32ThreadID != currentThreadId && count < capacity)
                {
                    HANDLE thread = OpenThread(THREAD_SUSPEND_RESUME, FALSE, entry.th32ThreadID);
                    if (thread != nullptr)
                    {
                        if (SuspendThread(thread) != static_cast<DWORD>(-1))
                        {
                            suspended[count++] = thread;
                        }
                        else
                        {
                            CloseHandle(thread);
                        }
                    }
                }
                entry.dwSize = sizeof(entry);
            } while (Thread32Next(snapshot, &entry));
        }
        CloseHandle(snapshot);
        return count;
    }

    void ResumeThreads(HANDLE* suspended, DWORD count)
    {
        if (suspended == nullptr) return;
        while (count > 0)
        {
            HANDLE thread = suspended[--count];
            ResumeThread(thread);
            CloseHandle(thread);
        }
    }

    bool InstallQueueHook()
    {
        BYTE* target = reinterpret_cast<BYTE*>(static_cast<std::uintptr_t>(g_gameBase + kQueueInsertRva));
        if (target == nullptr)
        {
            AppendQueueLog("ERROR: queue insertion target address is null.");
            return false;
        }

        if (std::memcmp(target, kExpectedPrologue, sizeof(kExpectedPrologue)) != 0)
        {
            AppendQueueLog("ERROR: AALib.exe+0xF2DE0 prologue does not match 55 8B EC 8B 45 08; hook was not installed.");
            return false;
        }

        BYTE* trampoline = reinterpret_cast<BYTE*>(VirtualAlloc(
            nullptr, 16, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
        if (trampoline == nullptr)
        {
            AppendQueueLog("ERROR: VirtualAlloc for queue trampoline failed.");
            return false;
        }

        std::memcpy(trampoline, target, sizeof(kExpectedPrologue));
        if (!MakeRelativeJump(trampoline + sizeof(kExpectedPrologue), target + sizeof(kExpectedPrologue), trampoline + sizeof(kExpectedPrologue)))
        {
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendQueueLog("ERROR: cannot encode trampoline return jump.");
            return false;
        }
        FlushInstructionCache(GetCurrentProcess(), trampoline, sizeof(kExpectedPrologue) + 5);

        BYTE patch[sizeof(kExpectedPrologue)]{};
        if (!MakeRelativeJump(target, reinterpret_cast<const void*>(&QueueInsertHook), patch))
        {
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendQueueLog("ERROR: cannot encode hook jump; target is outside rel32 range.");
            return false;
        }
        patch[5] = 0x90;

        HANDLE suspended[512]{};
        const DWORD suspendedCapacity = static_cast<DWORD>(sizeof(suspended) / sizeof(suspended[0]));
        const DWORD suspendedCount = SuspendOtherProcessThreads(suspended, suspendedCapacity);

        DWORD oldProtect = 0;
        if (!VirtualProtect(target, sizeof(patch), PAGE_EXECUTE_READWRITE, &oldProtect))
        {
            ResumeThreads(suspended, suspendedCount);
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendQueueLog("ERROR: VirtualProtect failed while installing queue hook.");
            return false;
        }

        if (std::memcmp(target, kExpectedPrologue, sizeof(kExpectedPrologue)) != 0)
        {
            DWORD ignored = 0;
            VirtualProtect(target, sizeof(patch), oldProtect, &ignored);
            ResumeThreads(suspended, suspendedCount);
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendQueueLog("ERROR: queue function changed before patching; hook was not installed.");
            return false;
        }

        g_hookTarget = target;
        g_trampoline = trampoline;
        g_originalQueueInsert = reinterpret_cast<QueueInsertFn>(trampoline);
        std::memcpy(target, patch, sizeof(patch));
        FlushInstructionCache(GetCurrentProcess(), target, sizeof(patch));
        InterlockedExchange(&g_hookInstalled, 1);

        DWORD ignored = 0;
        VirtualProtect(target, sizeof(patch), oldProtect, &ignored);
        ResumeThreads(suspended, suspendedCount);

        char message[512]{};
        sprintf_s(message,
            "CPU queue trace hook installed at RVA=0x%08lX; P1 queue=0x%08lX, P2 queue=0x%08lX; suspended %lu other process thread(s) during patch. Original function is preserved through a trampoline.",
            static_cast<unsigned long>(kQueueInsertRva),
            static_cast<unsigned long>(g_p1Queue),
            static_cast<unsigned long>(g_p2Queue),
            static_cast<unsigned long>(suspendedCount));
        AppendQueueLog(message);
        return true;
    }

    bool InstallEventDispatchHook()
    {
        BYTE* target = reinterpret_cast<BYTE*>(static_cast<std::uintptr_t>(g_gameBase + kEventDispatchRva));
        if (target == nullptr)
        {
            AppendDispatchLog("ERROR: event dispatch target address is null.");
            return false;
        }

        if (std::memcmp(target, kEventDispatchPrologue, sizeof(kEventDispatchPrologue)) != 0)
        {
            AppendDispatchLog("ERROR: AALib.exe+0xEE200 prologue does not match 55 8B EC 53 8B 5D 0C; hook was not installed.");
            return false;
        }

        BYTE* trampoline = reinterpret_cast<BYTE*>(VirtualAlloc(
            nullptr, sizeof(kEventDispatchPrologue) + 5, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
        if (trampoline == nullptr)
        {
            AppendDispatchLog("ERROR: VirtualAlloc for event dispatch trampoline failed.");
            return false;
        }

        std::memcpy(trampoline, target, sizeof(kEventDispatchPrologue));
        if (!MakeRelativeJump(trampoline + sizeof(kEventDispatchPrologue),
            target + sizeof(kEventDispatchPrologue),
            trampoline + sizeof(kEventDispatchPrologue)))
        {
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendDispatchLog("ERROR: cannot encode event dispatch trampoline return jump.");
            return false;
        }
        FlushInstructionCache(GetCurrentProcess(), trampoline, sizeof(kEventDispatchPrologue) + 5);

        BYTE patch[sizeof(kEventDispatchPrologue)]{};
        if (!MakeRelativeJump(target, reinterpret_cast<const void*>(&EventDispatchHook), patch))
        {
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendDispatchLog("ERROR: cannot encode event dispatch hook jump; target is outside rel32 range.");
            return false;
        }
        for (std::size_t i = 5; i < sizeof(patch); ++i) patch[i] = 0x90;

        HANDLE suspended[512]{};
        const DWORD suspendedCapacity = static_cast<DWORD>(sizeof(suspended) / sizeof(suspended[0]));
        const DWORD suspendedCount = SuspendOtherProcessThreads(suspended, suspendedCapacity);

        DWORD oldProtect = 0;
        if (!VirtualProtect(target, sizeof(patch), PAGE_EXECUTE_READWRITE, &oldProtect))
        {
            ResumeThreads(suspended, suspendedCount);
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendDispatchLog("ERROR: VirtualProtect failed while installing event dispatch hook.");
            return false;
        }

        if (std::memcmp(target, kEventDispatchPrologue, sizeof(kEventDispatchPrologue)) != 0)
        {
            DWORD ignored = 0;
            VirtualProtect(target, sizeof(patch), oldProtect, &ignored);
            ResumeThreads(suspended, suspendedCount);
            VirtualFree(trampoline, 0, MEM_RELEASE);
            AppendDispatchLog("ERROR: event dispatch function changed before patching; hook was not installed.");
            return false;
        }

        g_dispatchHookTarget = target;
        g_dispatchTrampoline = trampoline;
        g_originalEventDispatch = reinterpret_cast<EventDispatchFn>(trampoline);
        std::memcpy(target, patch, sizeof(patch));
        FlushInstructionCache(GetCurrentProcess(), target, sizeof(patch));
        InterlockedExchange(&g_dispatchHookInstalled, 1);

        DWORD ignored = 0;
        VirtualProtect(target, sizeof(patch), oldProtect, &ignored);
        ResumeThreads(suspended, suspendedCount);

        char message[512]{};
        sprintf_s(message,
            "CPU event dispatch hook installed at RVA=0x%08lX; P1 object=0x%08lX, P2 object=0x%08lX; suspended %lu other process thread(s) during patch. Original __thiscall function is preserved through a 7-byte trampoline.",
            static_cast<unsigned long>(kEventDispatchRva),
            static_cast<unsigned long>(g_playerP1),
            static_cast<unsigned long>(g_playerP2),
            static_cast<unsigned long>(suspendedCount));
        AppendDispatchLog(message);
        return true;
    }

    void FlushQueueSites()
    {
        for (DWORD i = 0; i < kSiteCapacity; ++i)
        {
            QueueSite& site = g_sites[i];
            if (InterlockedCompareExchange(&site.State, 0, 0) != 1)
            {
                continue;
            }

            const LONG count = InterlockedCompareExchange(&site.Count, 0, 0);
            const LONG reported = InterlockedCompareExchange(&site.ReportedCount, count, 0);
            if (reported == count)
            {
                continue;
            }
            InterlockedExchange(&site.ReportedCount, count);

            char message[768]{};
            sprintf_s(message,
                "QUEUE_EVENT result=%s side=P%lu callerRVA=0x%08lX tid(first)=%lu eventTypeArg=0x%08lX payloadArg=0x%08lX guardBefore=0x%02lX guardAfter=0x%02lX activeBefore=0x%02lX activeAfter=0x%02lX storedTypeAfter=0x%04lX storedPayloadAfter=0x%04lX totalHits=%ld",
                site.GuardBefore == 0 ? "ACCEPTED_BY_QUEUE" : "BLOCKED_BY_GUARD",
                static_cast<unsigned long>(site.Side),
                static_cast<unsigned long>(site.CallerRva),
                static_cast<unsigned long>(site.FirstThreadId),
                static_cast<unsigned long>(site.EventTypeArg),
                static_cast<unsigned long>(site.PayloadArg),
                static_cast<unsigned long>(site.GuardBefore),
                static_cast<unsigned long>(site.GuardAfter),
                static_cast<unsigned long>(site.ActiveBefore),
                static_cast<unsigned long>(site.ActiveAfter),
                static_cast<unsigned long>(site.StoredTypeAfter),
                static_cast<unsigned long>(site.StoredPayloadAfter),
                static_cast<long>(count));
            AppendQueueLog(message);
        }
    }

    void FlushQueueEventDetails()
    {
        for (;;)
        {
            QueueEventDetailRecord record{};
            AcquireSRWLockExclusive(&g_detailLock);
            if (g_detailCount == 0)
            {
                ReleaseSRWLockExclusive(&g_detailLock);
                break;
            }
            record = g_detailRecords[g_detailReadIndex];
            g_detailReadIndex = (g_detailReadIndex + 1u) % kDetailCapacity;
            --g_detailCount;
            ReleaseSRWLockExclusive(&g_detailLock);

            // The queue slot is released before string formatting and file I/O.
            char message[1200]{};
            int used = sprintf_s(message, sizeof(message),
                "QUEUE_EVENT_DETAIL seq=%lu qpc=%I64u side=P%lu tid=%lu tick=%lu caller=0x%08lX callerRVA=0x%08lX player=0x%08lX queue=0x%08lX eventType=0x%08lX payload=0x%08lX guardBefore=0x%02lX activeBefore=0x%02lX afterReadable=%lu guardAfter=0x%02lX activeAfter=0x%02lX storedAfter=(%04lX,%04lX) stackDepth=%lu stack=[",
                static_cast<unsigned long>(record.Sequence),
                static_cast<unsigned long long>(record.QpcTicks),
                static_cast<unsigned long>(record.Side),
                static_cast<unsigned long>(record.ThreadId),
                static_cast<unsigned long>(record.TickCount),
                static_cast<unsigned long>(record.CallerAddress),
                static_cast<unsigned long>(record.CallerRva),
                static_cast<unsigned long>(record.PlayerObject),
                static_cast<unsigned long>(record.QueueAddress),
                static_cast<unsigned long>(record.EventType),
                static_cast<unsigned long>(record.Payload),
                static_cast<unsigned long>(record.GuardBefore),
                static_cast<unsigned long>(record.ActiveBefore),
                static_cast<unsigned long>(record.AfterReadable),
                static_cast<unsigned long>(record.GuardAfter),
                static_cast<unsigned long>(record.ActiveAfter),
                static_cast<unsigned long>(record.StoredTypeAfter),
                static_cast<unsigned long>(record.StoredPayloadAfter),
                static_cast<unsigned long>(record.StackDepth));
            if (used > 0)
            {
                for (DWORD i = 0; i < record.StackDepth &&
                    static_cast<std::size_t>(used) < sizeof(message) - 20; ++i)
                {
                    const DWORD address = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(record.Stack[i]));
                    const int written = sprintf_s(message + used,
                        sizeof(message) - static_cast<std::size_t>(used),
                        "%s0x%08lX", i == 0 ? "" : ",", static_cast<unsigned long>(address));
                    if (written <= 0) break;
                    used += written;
                }
                if (static_cast<std::size_t>(used) < sizeof(message) - 2)
                    sprintf_s(message + used, sizeof(message) - static_cast<std::size_t>(used), "]");
                AppendQueueLog(message);
            }
        }
    }

    void FlushDispatchSites()
    {
        for (DWORD i = 0; i < kSiteCapacity; ++i)
        {
            EventDispatchSite& site = g_dispatchSites[i];
            if (InterlockedCompareExchange(&site.State, 0, 0) != 1) continue;

            const LONG count = InterlockedCompareExchange(&site.Count, 0, 0);
            const LONG reported = InterlockedCompareExchange(&site.ReportedCount, count, 0);
            if (reported == count) continue;
            InterlockedExchange(&site.ReportedCount, count);

            char message[1100]{};
            sprintf_s(message,
                "EVENT_DISPATCH side=P%lu callerRVA=0x%08lX tid(first)=%lu eventTypeArg=0x%08lX payloadArg=0x%08lX playerMode=0x%08lX queueActiveBefore=0x%02lX queueCurrentBefore=(%04lX,%04lX) queueHistoryBefore=(%04lX,%04lX) queueHistoryMatchesArgs=%lu guardBefore=0x%02lX queueActiveAfter=0x%02lX queueHistoryAfter=(%04lX,%04lX) totalHits=%ld",
                static_cast<unsigned long>(site.Side),
                static_cast<unsigned long>(site.CallerRva),
                static_cast<unsigned long>(site.FirstThreadId),
                static_cast<unsigned long>(site.EventTypeArg),
                static_cast<unsigned long>(site.PayloadArg),
                static_cast<unsigned long>(site.PlayerMode),
                static_cast<unsigned long>(site.QueueActiveBefore),
                static_cast<unsigned long>(site.QueueCurrentTypeBefore),
                static_cast<unsigned long>(site.QueueCurrentPayloadBefore),
                static_cast<unsigned long>(site.QueueHistoryTypeBefore),
                static_cast<unsigned long>(site.QueueHistoryPayloadBefore),
                static_cast<unsigned long>(site.QueueHistoryMatchesArgs),
                static_cast<unsigned long>(site.QueueGuardBefore),
                static_cast<unsigned long>(site.QueueActiveAfter),
                static_cast<unsigned long>(site.QueueHistoryTypeAfter),
                static_cast<unsigned long>(site.QueueHistoryPayloadAfter),
                static_cast<long>(count));
            AppendDispatchLog(message);
        }
    }

    DWORD WINAPI QueueTraceWorker(void*)
    {
        const int queueTraceEnabled = ReadIniInt(L"AIResearch", L"EnableCpuQueueTrace", 0);
        const int queueDetailTraceEnabled = ReadIniInt(L"AIResearch", L"EnableCpuQueueDetailTrace", 1);
        const int dispatchTraceEnabled = ReadIniInt(L"AIResearch", L"EnableCpuEventDispatchTrace", 0);
        InterlockedExchange(&g_detailTraceEnabled, queueDetailTraceEnabled != 0 ? 1 : 0);
        int flushMs = ReadIniInt(L"AIResearch", L"QueueTraceFlushIntervalMs", kDefaultFlushIntervalMs);
        if (flushMs < static_cast<int>(kMinFlushIntervalMs)) flushMs = kMinFlushIntervalMs;
        if (flushMs > static_cast<int>(kMaxFlushIntervalMs)) flushMs = kMaxFlushIntervalMs;
        g_flushIntervalMs = static_cast<DWORD>(flushMs);

        if (queueTraceEnabled == 0 && dispatchTraceEnabled == 0)
        {
            AppendQueueLog("CPU queue and event-dispatch traces are disabled in ArcanaAI.ini. No code hook was installed.");
            return 0;
        }

        for (int attempt = 0; attempt < 300; ++attempt)
        {
            g_gameModule = GetModuleHandleW(L"AALib.exe");
            if (g_gameModule != nullptr) break;
            Sleep(100);
        }
        if (g_gameModule == nullptr)
        {
            AppendQueueLog("ERROR: AALib.exe was not found; CPU queue trace stopped.");
            return 0;
        }

        g_gameBase = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(g_gameModule));
        DWORD timestamp = 0;
        if (!GetImageFingerprint32(g_gameModule, &g_gameImageSize, &timestamp) ||
            g_gameImageSize != kExpectedImageSize || timestamp != kExpectedTimeDateStamp ||
            kQueueInsertRva + sizeof(kExpectedPrologue) >= g_gameImageSize ||
            kEventDispatchRva + sizeof(kEventDispatchPrologue) >= g_gameImageSize ||
            kP1ControlRva < kPlayerControlOffset || kP2ControlRva < kPlayerControlOffset)
        {
            AppendQueueLog("ERROR: AALib.exe PE fingerprint does not match the analyzed binary; no code hook was installed.");
            return 0;
        }

        g_playerP1 = g_gameBase + kP1ControlRva - kPlayerControlOffset;
        g_playerP2 = g_gameBase + kP2ControlRva - kPlayerControlOffset;
        g_p1Queue = g_playerP1 + kPlayerQueueOffset;
        g_p2Queue = g_playerP2 + kPlayerQueueOffset;

        char start[640]{};
        sprintf_s(start,
            "Stage 11 tracing requested. gameBase=0x%08lX; P1 object=0x%08lX queue=0x%08lX; P2 object=0x%08lX queue=0x%08lX; queueInsert=%d; queueDetail=%d; eventDispatch=%d; flush=%lu ms. Exact P1/P2 CPU queues only.",
            static_cast<unsigned long>(g_gameBase),
            static_cast<unsigned long>(g_playerP1),
            static_cast<unsigned long>(g_p1Queue),
            static_cast<unsigned long>(g_playerP2),
            static_cast<unsigned long>(g_p2Queue),
            queueTraceEnabled != 0 ? 1 : 0,
            queueDetailTraceEnabled != 0 ? 1 : 0,
            dispatchTraceEnabled != 0 ? 1 : 0,
            static_cast<unsigned long>(g_flushIntervalMs));
        AppendQueueLog(start);
        AppendDispatchLog(start);

        if (queueTraceEnabled != 0 && !InstallQueueHook())
        {
            AppendDispatchLog("Queue insertion hook failed; event dispatch installation will still be attempted if enabled.");
        }
        if (dispatchTraceEnabled != 0 && !InstallEventDispatchHook())
        {
            AppendQueueLog("Event dispatch hook installation failed; queue insertion trace may still be active.");
        }
        if (InterlockedCompareExchange(&g_hookInstalled, 0, 0) == 0 &&
            InterlockedCompareExchange(&g_dispatchHookInstalled, 0, 0) == 0)
        {
            AppendQueueLog("ERROR: no Stage 5 trace hook was installed.");
            return 0;
        }

        for (;;)
        {
            Sleep(g_flushIntervalMs);
            if (queueTraceEnabled != 0 && InterlockedCompareExchange(&g_hookInstalled, 0, 0) != 0)
            {
                FlushQueueSites();
                if (queueDetailTraceEnabled != 0)
                    FlushQueueEventDetails();
                if (InterlockedCompareExchange(&g_detailDroppedRecords, 0, 0) != 0)
                {
                    char detailWarning[160]{};
                    sprintf_s(detailWarning, "WARNING: queue detail buffer full; dropped records=%ld (capacity=%lu).",
                        static_cast<long>(InterlockedCompareExchange(&g_detailDroppedRecords, 0, 0)),
                        static_cast<unsigned long>(kDetailCapacity));
                    AppendQueueLog(detailWarning);
                    InterlockedExchange(&g_detailDroppedRecords, 0);
                }
                if (InterlockedCompareExchange(&g_droppedSites, 0, 0) != 0)
                {
                    char warning[160]{};
                    sprintf_s(warning, "WARNING: queue trace site table full; dropped groups=%ld.",
                        static_cast<long>(InterlockedCompareExchange(&g_droppedSites, 0, 0)));
                    AppendQueueLog(warning);
                    InterlockedExchange(&g_droppedSites, 0);
                }
            }
            if (dispatchTraceEnabled != 0 && InterlockedCompareExchange(&g_dispatchHookInstalled, 0, 0) != 0)
            {
                FlushDispatchSites();
                if (InterlockedCompareExchange(&g_dispatchDroppedSites, 0, 0) != 0)
                {
                    char warning[160]{};
                    sprintf_s(warning, "WARNING: event dispatch trace site table full; dropped groups=%ld.",
                        static_cast<long>(InterlockedCompareExchange(&g_dispatchDroppedSites, 0, 0)));
                    AppendDispatchLog(warning);
                    InterlockedExchange(&g_dispatchDroppedSites, 0);
                }
            }
        }
    }

    BOOL CALLBACK StartQueueTraceWorker(PINIT_ONCE, PVOID, PVOID*)
    {
        HANDLE thread = CreateThread(nullptr, 0, QueueTraceWorker, nullptr, 0, nullptr);
        if (thread == nullptr)
        {
            AppendQueueLog("ERROR: failed to create CPU queue trace worker thread.");
            return TRUE;
        }
        CloseHandle(thread);
        return TRUE;
    }
}

void StartAIQueueTrace(HMODULE proxyModule)
{
    g_proxyModule = proxyModule;
    InitOnceExecuteOnce(&g_startOnce, StartQueueTraceWorker, nullptr, nullptr);
}
