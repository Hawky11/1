#pragma once

#include <Windows.h>

// Optional diagnostic observers for CPU event mailboxes and dispatch.
// Hooks AALib.exe+0xF2DE0 (writer) and optionally AALib.exe+0xEE200 (dispatcher),
// preserves both original functions, and records only exact P1/P2 objects while
// their control DWORD is CPU. Both hooks are disabled by default in ArcanaAI.ini.
void StartAIQueueTrace(HMODULE proxyModule);
