#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <TlHelp32.h>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstddef>
#include <wchar.h>

#include "AITrace.h"
#include "ComVsCom.h"

namespace
{
    // RVAs confirmed from the user's correct COMvsCOM entry in the CE table.
    constexpr DWORD kP1ControlRva = 0x0DCA5EA4;
    constexpr DWORD kP2ControlRva = 0x0DCD0BCC;
    constexpr LONG kSiteCount = 128;
    constexpr DWORD kDefaultScanIntervalMs = 250;
    constexpr DWORD kMinimumScanIntervalMs = 50;
    constexpr DWORD kMaximumScanIntervalMs = 2000;

    struct TraceSite
    {
        // State: 0 = empty, -1 = being initialized, 1 = ready.
        volatile LONG State;
        volatile LONG Count;
        volatile LONG Reported;
        DWORD EipAfter;
        DWORD RvaAfter;
        DWORD ThreadId;
        DWORD Eax;
        DWORD Ebx;
        DWORD Ecx;
        DWORD Edx;
        DWORD Esi;
        DWORD Edi;
        DWORD Ebp;
        DWORD Esp;
        DWORD EFlags;
        BYTE CodeWindow[24]; // 16 bytes before EIP, then 8 bytes from EIP.
    };

    TraceSite g_sites[2][kSiteCount]{};
    INIT_ONCE g_startOnce = INIT_ONCE_STATIC_INIT;
    HMODULE g_proxyModule = nullptr;
    HMODULE g_gameModule = nullptr;
    PVOID g_vectoredHandler = nullptr;
    DWORD g_gameImageSize = 0;
    DWORD g_gameBase = 0;
    DWORD g_watchP1 = 0;
    DWORD g_watchP2 = 0;
    DWORD g_scanIntervalMs = kDefaultScanIntervalMs;
    volatile LONG g_firstInstallLog = 0;
    volatile LONG g_noThreadInstallLog = 0;

    // Keep handles for inspected threads so the scan loop does not suspend
    // every game thread every 250 ms. A signalled handle is a terminated thread;
    // its slot is then reclaimed (also making thread-ID reuse safe).
    struct TrackedThread
    {
        DWORD Id;
        HANDLE Handle;
        bool WatchpointsInstalled;
    };
    constexpr DWORD kTrackedThreadCapacity = 256;
    TrackedThread g_trackedThreads[kTrackedThreadCapacity]{};
    volatile LONG g_capacityWarningLogged = 0;

    bool GetSiblingPath(wchar_t* output, DWORD capacity, const wchar_t* filename)
    {
        if (output == nullptr || capacity == 0 || filename == nullptr || g_proxyModule == nullptr)
        {
            return false;
        }

        const DWORD length = GetModuleFileNameW(g_proxyModule, output, capacity);
        if (length == 0 || length >= capacity)
        {
            return false;
        }

        wchar_t* slash = wcsrchr(output, L'\\');
        wchar_t* forwardSlash = wcsrchr(output, L'/');
        if (forwardSlash != nullptr && (slash == nullptr || forwardSlash > slash))
        {
            slash = forwardSlash;
        }
        if (slash == nullptr)
        {
            return false;
        }

        *(slash + 1) = L'\0';
        const std::size_t used = wcslen(output);
        const std::size_t nameLength = wcslen(filename);
        if (used + nameLength + 1 > capacity)
        {
            return false;
        }
        wcscat_s(output, capacity, filename);
        return true;
    }

    void AppendTraceLog(const char* message)
    {
        wchar_t logPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(logPath, MAX_PATH, L"ArcanaAI_Trace.log"))
        {
            return;
        }

        SYSTEMTIME now{};
        GetLocalTime(&now);

        char line[2048]{};
        const int count = sprintf_s(
            line,
            "[%04u-%02u-%02u %02u:%02u:%02u] %s\r\n",
            now.wYear, now.wMonth, now.wDay,
            now.wHour, now.wMinute, now.wSecond,
            message != nullptr ? message : "(empty)");
        if (count <= 0)
        {
            return;
        }

        HANDLE file = CreateFileW(
            logPath,
            FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            nullptr);
        if (file == INVALID_HANDLE_VALUE)
        {
            return;
        }

        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(count), &written, nullptr);
        CloseHandle(file);
    }

    int ReadIniInt(const wchar_t* section, const wchar_t* key, int defaultValue)
    {
        wchar_t iniPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(iniPath, MAX_PATH, L"ArcanaAI.ini"))
        {
            return defaultValue;
        }
        return GetPrivateProfileIntW(section, key, defaultValue, iniPath);
    }

    DWORD GetImageSize32(HMODULE module)
    {
        if (module == nullptr)
        {
            return 0;
        }

        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(module);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0)
        {
            return 0;
        }

        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(
            reinterpret_cast<const BYTE*>(module) + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC)
        {
            return 0;
        }
        return nt->OptionalHeader.SizeOfImage;
    }

    bool IsGameImageAddress(DWORD address)
    {
        return g_gameBase != 0 && g_gameImageSize != 0 &&
            address >= g_gameBase + 0x1000 && address - g_gameBase < g_gameImageSize;
    }

    void CaptureCodeWindow(DWORD eipAfter, BYTE output[24])
    {
        std::memset(output, 0, 24);
        if (g_gameBase == 0 || eipAfter < g_gameBase + 0x1000 ||
            eipAfter >= g_gameBase + g_gameImageSize)
        {
            return;
        }

        DWORD start = eipAfter >= g_gameBase + 0x1010 ? eipAfter - 16 : g_gameBase + 0x1000;
        MEMORY_BASIC_INFORMATION info{};
        if (VirtualQuery(reinterpret_cast<const void*>(start), &info, sizeof(info)) != sizeof(info))
        {
            return;
        }
        if (info.State != MEM_COMMIT || (info.Protect & PAGE_GUARD) != 0 ||
            (info.Protect & 0xFF) == PAGE_NOACCESS)
        {
            return;
        }

        const auto regionStart = reinterpret_cast<std::uintptr_t>(info.BaseAddress);
        const auto regionEnd = regionStart + info.RegionSize;
        const auto copyStart = static_cast<std::uintptr_t>(start);
        const std::size_t available = copyStart < regionEnd
            ? static_cast<std::size_t>(regionEnd - copyStart)
            : 0;
        const std::size_t length = available < 24 ? available : 24;
        if (length != 0)
        {
            std::memcpy(output, reinterpret_cast<const void*>(start), length);
        }
    }

    void AddTraceSite(int fieldIndex, PCONTEXT context)
    {
        if (fieldIndex < 0 || fieldIndex > 1 || context == nullptr)
        {
            return;
        }

        const DWORD eip = context->Eip;
        if (eip == 0)
        {
            return;
        }

        const DWORD startIndex = ((eip >> 4) ^ (static_cast<DWORD>(fieldIndex + 1) * 0x9E3779B9u)) % kSiteCount;
        for (DWORD probe = 0; probe < static_cast<DWORD>(kSiteCount); ++probe)
        {
            TraceSite& site = g_sites[fieldIndex][(startIndex + probe) % kSiteCount];
            const LONG state = InterlockedCompareExchange(&site.State, 0, 0);

            if (state == 1 && site.EipAfter == eip)
            {
                InterlockedIncrement(&site.Count);
                return;
            }

            if (state == 0 && InterlockedCompareExchange(&site.State, -1, 0) == 0)
            {
                site.EipAfter = eip;
                site.RvaAfter = eip - g_gameBase;
                site.ThreadId = GetCurrentThreadId();
                site.Eax = context->Eax;
                site.Ebx = context->Ebx;
                site.Ecx = context->Ecx;
                site.Edx = context->Edx;
                site.Esi = context->Esi;
                site.Edi = context->Edi;
                site.Ebp = context->Ebp;
                site.Esp = context->Esp;
                site.EFlags = context->EFlags;
                CaptureCodeWindow(eip, site.CodeWindow);
                InterlockedExchange(&site.Count, 1);
                InterlockedExchange(&site.State, 1);
                return;
            }
        }
    }

    LONG CALLBACK TraceExceptionHandler(EXCEPTION_POINTERS* exceptionInfo)
    {
        if (exceptionInfo == nullptr || exceptionInfo->ExceptionRecord == nullptr ||
            exceptionInfo->ContextRecord == nullptr ||
            exceptionInfo->ExceptionRecord->ExceptionCode != EXCEPTION_SINGLE_STEP)
        {
            return EXCEPTION_CONTINUE_SEARCH;
        }

        PCONTEXT context = exceptionInfo->ContextRecord;
        const DWORD dr6 = context->Dr6;
        const DWORD ownedHits = dr6 & 0x3;
        const DWORD commandTraceHits = dr6 & 0xCu; // DR2/DR3 belong to AICommandTrace.
        const DWORD otherDebugHits = dr6 & 0x0000E000u; // BD, BS, BT only.
        if (ownedHits == 0 || otherDebugHits != 0)
        {
            return EXCEPTION_CONTINUE_SEARCH;
        }

        // Clear only the status bits belonging to our two data watchpoints.
        context->Dr6 &= ~0x3u;
        if (commandTraceHits != 0)
        {
            // Let AICommandTrace consume its DR2/DR3 hit in the next VEH handler.
            return EXCEPTION_CONTINUE_SEARCH;
        }

        // Keep only accesses executed by AALib.exe itself. This excludes our
        // COMvsCOM writer and operating-system routines from the trace.
        if (!IsGameImageAddress(context->Eip))
        {
            return EXCEPTION_CONTINUE_EXECUTION;
        }

        if ((ownedHits & 0x1) != 0)
        {
            AddTraceSite(0, context);
        }
        if ((ownedHits & 0x2) != 0)
        {
            AddTraceSite(1, context);
        }

        return EXCEPTION_CONTINUE_EXECUTION;
    }

    bool IsOurWatchpointConfiguration(const CONTEXT& context)
    {
        return context.Dr0 == g_watchP1 &&
            context.Dr1 == g_watchP2 &&
            (context.Dr7 & 0x0000000Fu) == 0x00000005u &&
            (context.Dr7 & 0x00FF0000u) == 0x00FF0000u;
    }

    void PruneTrackedThreads()
    {
        for (DWORD i = 0; i < kTrackedThreadCapacity; ++i)
        {
            TrackedThread& slot = g_trackedThreads[i];
            if (slot.Handle != nullptr && WaitForSingleObject(slot.Handle, 0) == WAIT_OBJECT_0)
            {
                CloseHandle(slot.Handle);
                slot = {};
            }
        }
    }

    bool IsThreadTracked(DWORD threadId)
    {
        for (DWORD i = 0; i < kTrackedThreadCapacity; ++i)
        {
            if (g_trackedThreads[i].Handle != nullptr && g_trackedThreads[i].Id == threadId)
            {
                return true;
            }
        }
        return false;
    }

    bool InspectThreadAndKeepHandle(DWORD threadId, HANDLE* retainedHandle, bool* watchpointsInstalled)
    {
        if (retainedHandle == nullptr || watchpointsInstalled == nullptr ||
            threadId == GetCurrentThreadId())
        {
            return false;
        }

        *retainedHandle = nullptr;
        *watchpointsInstalled = false;

        HANDLE thread = OpenThread(
            THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_SET_CONTEXT |
                THREAD_QUERY_INFORMATION | SYNCHRONIZE,
            FALSE,
            threadId);
        if (thread == nullptr)
        {
            return false;
        }

        bool inspected = false;
        bool installed = false;
        const DWORD suspendResult = SuspendThread(thread);
        if (suspendResult != static_cast<DWORD>(-1))
        {
            CONTEXT context{};
            context.ContextFlags = CONTEXT_DEBUG_REGISTERS;
            if (GetThreadContext(thread, &context))
            {
                inspected = true;
                if (IsOurWatchpointConfiguration(context))
                {
                    installed = true;
                }
                else if ((context.Dr7 & 0x0000000Fu) == 0)
                {
                    context.Dr0 = g_watchP1;
                    context.Dr1 = g_watchP2;
                    context.Dr6 &= ~0x3u;
                    // DR0/DR1: local enable; read/write; length = 4 bytes.
                    // Preserve DR2/DR3 and unrelated DR7 control bits.
                    context.Dr7 = (context.Dr7 & ~0x00FF000Fu) | 0x00FF0005u;
                    installed = SetThreadContext(thread, &context) != FALSE;
                }
                // If DR0/DR1 belong to another debugger/tool, keep the thread
                // tracked but leave its debug-register state untouched.
            }
            ResumeThread(thread);
        }

        if (!inspected)
        {
            CloseHandle(thread);
            return false;
        }

        *retainedHandle = thread;
        *watchpointsInstalled = installed;
        return true;
    }

    DWORD InstallWatchpointsOnCurrentThreads()
    {
        const DWORD processId = GetCurrentProcessId();
        const DWORD currentThreadId = GetCurrentThreadId();
        const DWORD comVsComThreadId = GetComVsComThreadId();
        DWORD newlyInstalled = 0;
        DWORD newlyInspected = 0;
        PruneTrackedThreads();

        HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
        {
            return 0;
        }

        THREADENTRY32 entry{};
        entry.dwSize = sizeof(entry);
        if (Thread32First(snapshot, &entry))
        {
            do
            {
                if (entry.th32OwnerProcessID == processId &&
                    entry.th32ThreadID != currentThreadId &&
                    entry.th32ThreadID != comVsComThreadId &&
                    !IsThreadTracked(entry.th32ThreadID))
                {
                    HANDLE retainedHandle = nullptr;
                    bool watchpointsInstalled = false;
                    if (InspectThreadAndKeepHandle(
                        entry.th32ThreadID, &retainedHandle, &watchpointsInstalled))
                    {
                        bool stored = false;
                        for (DWORD slotIndex = 0; slotIndex < kTrackedThreadCapacity; ++slotIndex)
                        {
                            TrackedThread& slot = g_trackedThreads[slotIndex];
                            if (slot.Handle == nullptr)
                            {
                                slot.Id = entry.th32ThreadID;
                                slot.Handle = retainedHandle;
                                slot.WatchpointsInstalled = watchpointsInstalled;
                                stored = true;
                                ++newlyInspected;
                                if (watchpointsInstalled)
                                {
                                    ++newlyInstalled;
                                }
                                break;
                            }
                        }

                        if (!stored)
                        {
                            CloseHandle(retainedHandle);
                            if (InterlockedCompareExchange(&g_capacityWarningLogged, 1, 0) == 0)
                            {
                                AppendTraceLog("WARNING: tracked-thread capacity reached; additional threads will not be watched.");
                            }
                        }
                    }
                }
                entry.dwSize = sizeof(entry);
            } while (Thread32Next(snapshot, &entry));
        }

        CloseHandle(snapshot);
        if (newlyInspected != 0 && newlyInstalled == 0 &&
            InterlockedCompareExchange(&g_noThreadInstallLog, 1, 0) == 0)
        {
            AppendTraceLog("Threads were inspected, but DR0/DR1 were unavailable or could not be set. Existing debug-register owners were left untouched.");
        }
        return newlyInstalled;
    }

    void FlushNewSites()
    {
        for (int field = 0; field < 2; ++field)
        {
            for (LONG i = 0; i < kSiteCount; ++i)
            {
                TraceSite& site = g_sites[field][i];
                if (InterlockedCompareExchange(&site.State, 0, 0) != 1 ||
                    InterlockedCompareExchange(&site.Reported, 1, 0) != 0)
                {
                    continue;
                }

                char codeHex[24 * 3 + 1]{};
                for (int j = 0; j < 24; ++j)
                {
                    sprintf_s(codeHex + j * 3, sizeof(codeHex) - j * 3, "%02X ", site.CodeWindow[j]);
                }

                char message[1536]{};
                sprintf_s(
                    message,
                    "WATCH_SITE field=%s tid=%lu EIP_after=0x%08lX RVA_after=0x%08lX hits=%ld "
                    "EAX=%08lX EBX=%08lX ECX=%08lX EDX=%08lX ESI=%08lX EDI=%08lX EBP=%08lX ESP=%08lX "
                    "EFLAGS=%08lX bytes_at_EIP_minus_16=%s",
                    field == 0 ? "P1_COM" : "P2_COM",
                    static_cast<unsigned long>(site.ThreadId),
                    static_cast<unsigned long>(site.EipAfter),
                    static_cast<unsigned long>(site.RvaAfter),
                    static_cast<long>(InterlockedCompareExchange(&site.Count, 0, 0)),
                    static_cast<unsigned long>(site.Eax),
                    static_cast<unsigned long>(site.Ebx),
                    static_cast<unsigned long>(site.Ecx),
                    static_cast<unsigned long>(site.Edx),
                    static_cast<unsigned long>(site.Esi),
                    static_cast<unsigned long>(site.Edi),
                    static_cast<unsigned long>(site.Ebp),
                    static_cast<unsigned long>(site.Esp),
                    static_cast<unsigned long>(site.EFlags),
                    codeHex);
                AppendTraceLog(message);
            }
        }
    }

    DWORD WINAPI FieldTraceThread(void*)
    {
        const int enabled = ReadIniInt(L"AIResearch", L"EnableControlFieldTrace", 0);
        int interval = ReadIniInt(L"AIResearch", L"ThreadScanIntervalMs", static_cast<int>(kDefaultScanIntervalMs));
        if (interval < static_cast<int>(kMinimumScanIntervalMs)) interval = static_cast<int>(kMinimumScanIntervalMs);
        if (interval > static_cast<int>(kMaximumScanIntervalMs)) interval = static_cast<int>(kMaximumScanIntervalMs);
        g_scanIntervalMs = static_cast<DWORD>(interval);

        if (enabled == 0)
        {
            AppendTraceLog("AI field trace is disabled in ArcanaAI.ini. No hardware watchpoints were installed.");
            return 0;
        }

        for (int attempt = 0; attempt < 300 && g_gameModule == nullptr; ++attempt)
        {
            g_gameModule = GetModuleHandleW(L"AALib.exe");
            if (g_gameModule == nullptr)
            {
                Sleep(100);
            }
        }

        if (g_gameModule == nullptr)
        {
            AppendTraceLog("ERROR: AALib.exe was not found; AI field trace stopped.");
            return 0;
        }

        g_gameBase = static_cast<DWORD>(reinterpret_cast<std::uintptr_t>(g_gameModule));
        g_gameImageSize = GetImageSize32(g_gameModule);
        if (g_gameImageSize == 0 ||
            kP1ControlRva > g_gameImageSize - sizeof(DWORD) ||
            kP2ControlRva > g_gameImageSize - sizeof(DWORD))
        {
            AppendTraceLog("ERROR: the loaded AALib.exe image does not contain both confirmed COM control RVAs.");
            return 0;
        }

        g_watchP1 = g_gameBase + kP1ControlRva;
        g_watchP2 = g_gameBase + kP2ControlRva;

        // Wait until the COMvsCOM writer publishes its thread ID. We must not
        // install data breakpoints on that writer or its 10 ms polling stores
        // would generate noise in the trace.
        DWORD comThreadId = 0;
        for (int attempt = 0; attempt < 100 && comThreadId == 0; ++attempt)
        {
            comThreadId = GetComVsComThreadId();
            if (comThreadId == 0)
            {
                Sleep(20);
            }
        }
        if (comThreadId == 0)
        {
            AppendTraceLog("ERROR: COMvsCOM worker thread ID was not published; tracer stopped to avoid watching its own writer.");
            return 0;
        }

        if (g_vectoredHandler == nullptr)
        {
            g_vectoredHandler = AddVectoredExceptionHandler(1, TraceExceptionHandler);
        }
        if (g_vectoredHandler == nullptr)
        {
            AppendTraceLog("ERROR: AddVectoredExceptionHandler failed; AI field trace stopped.");
            return 0;
        }

        char startMessage[512]{};
        sprintf_s(
            startMessage,
            "AI control-field trace active. Watching reads/writes at P1=0x%08lX (RVA 0x%08lX), "
            "P2=0x%08lX (RVA 0x%08lX). Thread scan interval=%lu ms. COMvsCOM writer TID=%lu is excluded; existing DR0/DR1 owners are not overwritten.",
            static_cast<unsigned long>(g_watchP1),
            static_cast<unsigned long>(kP1ControlRva),
            static_cast<unsigned long>(g_watchP2),
            static_cast<unsigned long>(kP2ControlRva),
            static_cast<unsigned long>(g_scanIntervalMs),
            static_cast<unsigned long>(comThreadId));
        AppendTraceLog(startMessage);

        for (;;)
        {
            const DWORD newlyInstalled = InstallWatchpointsOnCurrentThreads();
            if (newlyInstalled != 0 && InterlockedCompareExchange(&g_firstInstallLog, 1, 0) == 0)
            {
                char message[256]{};
                sprintf_s(message, "Hardware watchpoints installed on %lu existing game thread(s); new threads will be checked automatically.",
                    static_cast<unsigned long>(newlyInstalled));
                AppendTraceLog(message);
            }
            else if (newlyInstalled == 0 && InterlockedCompareExchange(&g_noThreadInstallLog, 1, 0) == 0)
            {
                AppendTraceLog("No eligible game thread accepted DR0/DR1 yet. Threads using those debug-register slots are left untouched; scanning will continue.");
            }

            FlushNewSites();
            Sleep(g_scanIntervalMs);
        }
    }

    BOOL CALLBACK StartTraceWorker(PINIT_ONCE, PVOID, PVOID*)
    {
        HANDLE thread = CreateThread(nullptr, 0, FieldTraceThread, nullptr, 0, nullptr);
        if (thread == nullptr)
        {
            AppendTraceLog("ERROR: failed to create AI field-trace worker thread.");
            return TRUE;
        }
        CloseHandle(thread);
        return TRUE;
    }
}

void StartAIFieldTrace(HMODULE proxyModule)
{
    if (proxyModule != nullptr)
    {
        g_proxyModule = proxyModule;
    }

    InitOnceExecuteOnce(&g_startOnce, StartTraceWorker, nullptr, nullptr);
}
