#pragma once

#include <Windows.h>

// Optional, read-only diagnostic tracer for accesses to the two confirmed
// COM control DWORDs. Disabled by default in ArcanaAI.ini.
void StartAIFieldTrace(HMODULE proxyModule);
