#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <cstdint>
#include <cstddef>
#include <stdio.h>
#include <wchar.h>

#include "ComVsCom.h"

namespace
{
    // Confirmed from the user's uploaded Cheat Engine table:
    // P1 = AALib.exe + 0xDCA5EA4
    // P2 = AALib.exe + 0xDCD0BCC
    constexpr std::uintptr_t kP1ControlRva = 0x0DCA5EA4;
    constexpr std::uintptr_t kP2ControlRva = 0x0DCD0BCC;

    INIT_ONCE g_workerInitOnce = INIT_ONCE_STATIC_INIT;
    HMODULE g_proxyModule = nullptr;
    volatile LONG g_comVsComThreadId = 0;

    bool GetSiblingPath(wchar_t* output, DWORD capacity, const wchar_t* filename)
    {
        if (output == nullptr || capacity == 0 || filename == nullptr || g_proxyModule == nullptr)
        {
            return false;
        }

        const DWORD length = GetModuleFileNameW(g_proxyModule, output, capacity);
        if (length == 0 || length >= capacity)
        {
            return false;
        }

        wchar_t* slash = wcsrchr(output, L'\\');
        wchar_t* forwardSlash = wcsrchr(output, L'/');
        if (forwardSlash != nullptr && (slash == nullptr || forwardSlash > slash))
        {
            slash = forwardSlash;
        }
        if (slash == nullptr)
        {
            return false;
        }

        *(slash + 1) = L'\0';
        const std::size_t used = wcslen(output);
        const std::size_t nameLength = wcslen(filename);
        if (used + nameLength + 1 > capacity)
        {
            return false;
        }
        wcscat_s(output, capacity, filename);
        return true;
    }

    void AppendLog(const char* message)
    {
        wchar_t logPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(logPath, MAX_PATH, L"ArcanaAI.log"))
        {
            return;
        }

        SYSTEMTIME now{};
        GetLocalTime(&now);

        char line[768]{};
        const int count = sprintf_s(
            line,
            "[%04u-%02u-%02u %02u:%02u:%02u] %s\r\n",
            now.wYear, now.wMonth, now.wDay,
            now.wHour, now.wMinute, now.wSecond,
            message != nullptr ? message : "(empty)");
        if (count <= 0)
        {
            return;
        }

        HANDLE file = CreateFileW(
            logPath,
            FILE_APPEND_DATA,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            nullptr,
            OPEN_ALWAYS,
            FILE_ATTRIBUTE_NORMAL,
            nullptr);
        if (file == INVALID_HANDLE_VALUE)
        {
            return;
        }

        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(count), &written, nullptr);
        CloseHandle(file);
    }

    int ReadIniInt(const wchar_t* section, const wchar_t* key, int defaultValue)
    {
        wchar_t iniPath[MAX_PATH + 1]{};
        if (!GetSiblingPath(iniPath, MAX_PATH, L"ArcanaAI.ini"))
        {
            return defaultValue;
        }
        return GetPrivateProfileIntW(section, key, defaultValue, iniPath);
    }

    DWORD GetImageSize(HMODULE module)
    {
        if (module == nullptr)
        {
            return 0;
        }

        const auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(module);
        if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0)
        {
            return 0;
        }

        const auto* nt = reinterpret_cast<const IMAGE_NT_HEADERS32*>(
            reinterpret_cast<const BYTE*>(module) + dos->e_lfanew);
        if (nt->Signature != IMAGE_NT_SIGNATURE ||
            nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR32_MAGIC)
        {
            return 0;
        }
        return nt->OptionalHeader.SizeOfImage;
    }

    bool IsWritableDword(const volatile LONG* address)
    {
        MEMORY_BASIC_INFORMATION info{};
        if (VirtualQuery(const_cast<const LONG*>(address), &info, sizeof(info)) != sizeof(info))
        {
            return false;
        }
        if (info.State != MEM_COMMIT || (info.Protect & PAGE_GUARD) != 0)
        {
            return false;
        }

        const DWORD protection = info.Protect & 0xFF;
        const bool writable =
            protection == PAGE_READWRITE ||
            protection == PAGE_WRITECOPY ||
            protection == PAGE_EXECUTE_READWRITE ||
            protection == PAGE_EXECUTE_WRITECOPY;
        if (!writable)
        {
            return false;
        }

        const auto start = reinterpret_cast<std::uintptr_t>(address);
        const auto end = reinterpret_cast<std::uintptr_t>(info.BaseAddress) + info.RegionSize;
        return start + sizeof(LONG) <= end;
    }

    DWORD WINAPI ComVsComThread(void*)
    {
        InterlockedExchange(&g_comVsComThreadId, static_cast<LONG>(GetCurrentThreadId()));
        const int enabled = ReadIniInt(L"COM", L"ForceCpuForBoth", 1);
        int interval = ReadIniInt(L"COM", L"WriteIntervalMs", 10);
        if (interval < 1) interval = 1;
        if (interval > 1000) interval = 1000;

        HMODULE game = nullptr;
        for (int attempt = 0; attempt < 300 && game == nullptr; ++attempt)
        {
            game = GetModuleHandleW(L"AALib.exe");
            if (game == nullptr)
            {
                Sleep(100);
            }
        }

        if (game == nullptr)
        {
            AppendLog("ERROR: AALib.exe module was not found; COMvsCOM worker stopped.");
            return 0;
        }

        const DWORD imageSize = GetImageSize(game);
        if (imageSize < sizeof(LONG) ||
            kP1ControlRva > imageSize - sizeof(LONG) ||
            kP2ControlRva > imageSize - sizeof(LONG))
        {
            AppendLog("ERROR: AALib.exe image size does not contain the confirmed COM control offsets.");
            return 0;
        }

        auto* p1 = reinterpret_cast<volatile LONG*>(
            reinterpret_cast<std::uintptr_t>(game) + kP1ControlRva);
        auto* p2 = reinterpret_cast<volatile LONG*>(
            reinterpret_cast<std::uintptr_t>(game) + kP2ControlRva);

        if (enabled == 0)
        {
            if (IsWritableDword(p1) && IsWritableDword(p2))
            {
                // Mirrors the uploaded CE [DISABLE] state: P1 = Human, P2 = CPU.
                InterlockedExchange(p1, 0);
                InterlockedExchange(p2, 1);
                AppendLog("COMvsCOM is disabled by ArcanaAI.ini; restored P1=0, P2=1.");
            }
            else
            {
                AppendLog("COMvsCOM is disabled by ArcanaAI.ini; target memory is not writable yet.");
            }
            return 0;
        }

        bool loggedActive = false;
        bool loggedWaiting = false;
        for (;;)
        {
            if (IsWritableDword(p1) && IsWritableDword(p2))
            {
                // Exact behavior of the user's correct COMvsCOM table entry:
                // DWORD 1 (CPU) to both fields, repeatedly.
                InterlockedExchange(p1, 1);
                InterlockedExchange(p2, 1);

                if (!loggedActive)
                {
                    AppendLog("COMvsCOM active: P1 and P2 control DWORDs are being forced to 1 (CPU).");
                    loggedActive = true;
                }
            }
            else if (!loggedActive && !loggedWaiting)
            {
                AppendLog("Waiting for COM control memory pages to become writable...");
                loggedWaiting = true;
            }

            Sleep(static_cast<DWORD>(interval));
        }
    }

    BOOL CALLBACK StartWorker(PINIT_ONCE, PVOID, PVOID*)
    {
        HANDLE thread = CreateThread(nullptr, 0, ComVsComThread, nullptr, 0, nullptr);
        if (thread == nullptr)
        {
            AppendLog("ERROR: failed to create COMvsCOM worker thread.");
            return TRUE;
        }
        CloseHandle(thread);
        return TRUE;
    }
}

DWORD GetComVsComThreadId()
{
    return static_cast<DWORD>(InterlockedCompareExchange(&g_comVsComThreadId, 0, 0));
}

void StartComVsCom(HMODULE proxyModule)
{
    if (proxyModule != nullptr)
    {
        g_proxyModule = proxyModule;
    }
    InitOnceExecuteOnce(&g_workerInitOnce, StartWorker, nullptr, nullptr);
}
