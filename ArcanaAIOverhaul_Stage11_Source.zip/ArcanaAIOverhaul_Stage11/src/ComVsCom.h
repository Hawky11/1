#pragma once

#include <Windows.h>

void StartComVsCom(HMODULE proxyModule);
DWORD GetComVsComThreadId();
