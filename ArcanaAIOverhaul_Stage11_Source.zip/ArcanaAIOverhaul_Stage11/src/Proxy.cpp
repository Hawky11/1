#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#include <Unknwn.h>
#include <string>

#include "ComVsCom.h"
#include "AITrace.h"
#include "AICommandTrace.h"
#include "AIQueueTrace.h"
#include "AICommandSiteTrace.h"
#include "AIProducerContextTrace.h"
#include "AIParentFlowTrace.h"

namespace
{
    HMODULE g_module = nullptr;
    HMODULE g_systemDinput8 = nullptr;

    using DirectInput8CreateProc = HRESULT(WINAPI*)(
        HINSTANCE,
        DWORD,
        REFIID,
        LPVOID*,
        LPUNKNOWN);

    DirectInput8CreateProc g_realDirectInput8Create = nullptr;
    INIT_ONCE g_realDllInitOnce = INIT_ONCE_STATIC_INIT;

    BOOL CALLBACK LoadSystemDinput8(PINIT_ONCE, PVOID, PVOID*)
    {
        wchar_t systemDirectory[MAX_PATH + 2]{};
        const UINT length = GetSystemDirectoryW(systemDirectory, MAX_PATH);
        if (length == 0 || length >= MAX_PATH)
        {
            return TRUE;
        }

        std::wstring path(systemDirectory, length);
        if (!path.empty() && path.back() != L'\\')
        {
            path.push_back(L'\\');
        }
        path += L"dinput8.dll";

        // Absolute System32/SysWOW64 path prevents loading this proxy recursively.
        g_systemDinput8 = LoadLibraryW(path.c_str());
        if (g_systemDinput8 != nullptr)
        {
            g_realDirectInput8Create = reinterpret_cast<DirectInput8CreateProc>(
                GetProcAddress(g_systemDinput8, "DirectInput8Create"));
        }

        return TRUE;
    }
}

extern "C" HRESULT WINAPI DirectInput8Create(
    HINSTANCE instance,
    DWORD version,
    REFIID interfaceId,
    LPVOID* output,
    LPUNKNOWN outer)
{
    if (!InitOnceExecuteOnce(&g_realDllInitOnce, LoadSystemDinput8, nullptr, nullptr) ||
        g_realDirectInput8Create == nullptr)
    {
        if (output != nullptr)
        {
            *output = nullptr;
        }
        SetLastError(ERROR_MOD_NOT_FOUND);
        return HRESULT_FROM_WIN32(ERROR_MOD_NOT_FOUND);
    }

    const HRESULT result = g_realDirectInput8Create(
        instance, version, interfaceId, output, outer);

    // This is called after the loader has finished resolving the EXE imports,
    // so starting our worker here avoids creating a thread from DllMain.
    StartComVsCom(g_module);
    StartAIFieldTrace(g_module);
    StartAICommandTrace(g_module);
    StartAIQueueTrace(g_module);
    StartAICommandSiteTrace(g_module);
    StartAIProducerContextTrace(g_module);
    StartAIParentFlowTrace(g_module);
    return result;
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID)
{
    if (reason == DLL_PROCESS_ATTACH)
    {
        g_module = instance;
        DisableThreadLibraryCalls(instance);
    }
    return TRUE;
}
